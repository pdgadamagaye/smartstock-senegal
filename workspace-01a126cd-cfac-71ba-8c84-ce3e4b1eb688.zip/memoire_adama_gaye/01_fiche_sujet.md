# 📄 FICHE SUJET DE MÉMOIRE

**Université Catholique de l'Afrique de l'Ouest (UCAO) — Dakar, Sénégal**  
**Licence 3 — Informatique de Gestion — Année Académique 2026-2027**

---

| | |
|---|---|
| **Étudiant** | Adama GAYE |
| **Encadrant** | [À compléter] |
| **Date de dépôt** | Août 2026 |

---

## TITRE DU MÉMOIRE

**« Conception et mise en œuvre d'un système d'aide à la décision pour les PME sénégalaises : intégration de la prédiction des ventes par intelligence artificielle, du pilotage par tableau de bord et de l'automatisation du reporting — cas de la CDA (Chaîne de Distribution Alimentaire) »**

---

## CONTEXTE ET JUSTIFICATION

Les PME sénégalaises du secteur de la distribution agroalimentaire font face à trois défis majeurs :

1. **L'absence d'outils de prévision** adaptés aux spécificités culturelles et saisonnières du marché sénégalais
2. **Le manque de visibilité en temps réel** sur les indicateurs de performance
3. **La lourdeur du reporting** généré manuellement

La **Chaîne de Distribution Alimentaire (CDA)**, société anonyme basée à Dakar (siège au Plateau, succursale à Sébikotane), illustre parfaitement ces problématiques. Ce projet propose une réponse intégrée à travers un système combinant :

- Un **module de prédiction des ventes** par intelligence artificielle (comparaison de 4 modèles)
- Un **tableau de bord interactif** de pilotage commercial
- Un **module d'automatisation du reporting** (génération automatique de rapports PDF)

---

## PROBLÉMATIQUE

> Comment concevoir un système d'aide à la décision intégré, combinant la prédiction des ventes par intelligence artificielle, le pilotage par tableau de bord en temps réel et l'automatisation du reporting, afin d'améliorer la performance commerciale des PME de distribution alimentaire sénégalaises ?

---

## HYPOTHÈSES DE RECHERCHE

**H1 :** Parmi les 4 modèles de séries temporelles testés (Moyenne Mobile, Holt-Winters, SARIMA, Prophet), le modèle Prophet enrichi de variables culturelles sénégalaises obtient les meilleures performances prédictives (MAPE < 15%).

**H2 :** Un tableau de bord centralisé multi-sites réduit le temps de prise de décision de plus de 60% par rapport aux méthodes traditionnelles.

**H3 :** L'automatisation du reporting réduit le temps consacré à la génération de rapports de 80% et élimine les erreurs manuelles.

---

## OBJECTIFS

### Objectif général

Concevoir et implémenter un système d'aide à la décision intégré pour les PME de distribution alimentaire sénégalaises, combinant prédiction IA, tableau de bord interactif et reporting automatisé.

### Objectifs spécifiques

- **OS1 :** Collecter et analyser les données historiques de ventes de la CDA
- **OS2 :** Implémenter et comparer 4 modèles de prédiction (Moyenne Mobile, Holt-Winters, SARIMA, Prophet)
- **OS3 :** Identifier le meilleur modèle et quantifier l'impact des variables culturelles (Ramadan, Tabaski)
- **OS4 :** Concevoir un tableau de bord interactif multi-sites avec KPIs en temps réel
- **OS5 :** Automatiser la génération de rapports commerciaux (PDF) périodiques
- **OS6 :** Implémenter un système d'alertes automatiques (seuils de stock, prédictions de rupture)
- **OS7 :** Valider le système avec les données réelles de la CDA et mesurer l'impact

---

## MÉTHODOLOGIE

| Phase | Durée | Activités |
|-------|-------|-----------|
| 1. Revue de littérature | Août-Sept. 2026 | Systèmes d'aide à la décision, modèles de prédiction, contexte PME |
| 2. Collecte de données | Sept. 2026 | Partenariat CDA, données historiques (12-24 mois) |
| 3. Expérimentation IA | Oct-Nov. 2026 | Implémentation et comparaison des 4 modèles |
| 4. Conception | Oct-Nov. 2026 | Merise (MCD/MLD) + UML |
| 5. Développement | Déc. 2026 - Fév. 2027 | Backend Django + Frontend React + Module IA + Reporting |
| 6. Tests et validation | Mars 2027 | Tests unitaires, intégration, validation CDA |
| 7. Rédaction | Jan-Mai 2027 | Mémoire complet (~130 pages) |
| 8. Soutenance | Juin 2027 | Présentation + démo live |

---

## ENTREPRISE CAS D'ÉTUDE : CDA

| Information | Détail |
|-------------|--------|
| **Raison sociale** | Chaîne de Distribution Alimentaire (CDA) |
| **Statut juridique** | Société Anonyme (SA) |
| **Secteur** | Commerce et distribution de produits alimentaires |
| **Siège** | 31 rue du Dr Thèze, Quartier Plateau, Dakar |
| **Succursale** | Sébikotane (Quartier Escale) |
| **Téléphone** | +221 33 823 11 20 / +221 33 836 33 04 |
| **Directeur Général** | M. Karim FILFILI |
| **Email** | karimfilfili@cdasenegal.com |

---

## TECHNOLOGIES UTILISÉES

| Catégorie | Technologie | Rôle |
|-----------|-------------|------|
| **IA / Prédiction** | Python, Prophet, statsmodels, scikit-learn | Comparaison de 4 modèles |
| **Backend** | Django 5.0 + Django REST Framework | API REST, logique métier |
| **Frontend** | React.js + Chart.js | Tableau de bord interactif |
| **Base de données** | PostgreSQL 15 | Stockage relationnel |
| **Reporting** | ReportLab + Pandas | Génération PDF automatisée |
| **Alertes** | Notifications in-app | Alertes dans le tableau de bord |
| **Hébergement** | Railway / Render (gratuit) | Déploiement |

---

## RÉSULTATS ATTENDUS

1. Un **tableau comparatif** des 4 modèles de prédiction (MAPE, RMSE, MAE)
2. Un **tableau de bord interactif** multi-sites avec KPIs en temps réel
3. Un **module de reporting automatisé** (rapports PDF générés automatiquement)
4. Un **système d'alertes** (stock critique, rupture prédite)
5. Des **mesures d'impact** chez la CDA : temps économisé, erreurs réduites, prédictions améliorées

---

## BIBLIOGRAPHIE INDICATIVE

1. Taylor, S. J., & Letham, B. (2018). Forecasting at scale. *The American Statistician*, 72(1), 37-45.
2. Hyndman, R. J., & Athanasopoulos, G. (2021). *Forecasting: Principles and Practice* (3rd ed.). OTexts.
3. Pressman, R. S. (2019). *Software Engineering: A Practitioner's Approach*. McGraw-Hill.
4. FAO. (2023). *The State of Food and Agriculture*. Rome.
5. ANSD. (2024). *Annuaire statistique du Sénégal*.

---

**Signature de l'étudiant :** _________________ **Date :** _________________

**Signature de l'encadrant :** _________________ **Date :** _________________

---

*Document généré le 12 août 2026 — Adama GAYE — UCAO Dakar*
