"""
SmartStock Sénégal - Module de Prédiction IA (Prophet)
======================================================
Ce module utilise Facebook Prophet pour prédire les ventes futures
à partir des données historiques de vente de la PME.

Auteur : Adama GAYE
Université : UCAO - Dakar
"""

import pandas as pd
import numpy as np
from prophet import Prophet
from prophet.diagnostics import cross_validation, performance_metrics
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)


class SalesPredictor:
    """
    Classe principale pour la prédiction des ventes.
    
    Utilise l'algorithme Prophet de Facebook pour :
    1. Entraîner un modèle sur les données historiques de ventes
    2. Prédire les ventes futures (7, 14, 30 jours)
    3. Évaluer la précision du modèle (MAPE, RMSE)
    """

    def __init__(self):
        self.model = None
        self.forecast = None
        self.is_trained = False
        self.training_data = None

    def prepare_data(self, sales_data):
        """
        Préparer les données pour Prophet.
        
        Prophet nécessite un DataFrame avec 2 colonnes :
        - 'ds' : date (datetime)
        - 'y' : valeur numérique (montant des ventes)
        
        Args:
            sales_data: Liste de dict ou DataFrame avec 'date' et 'total'
            
        Returns:
            DataFrame formaté pour Prophet
        """
        if isinstance(sales_data, list):
            df = pd.DataFrame(sales_data)
        else:
            df = sales_data.copy()

        # Renommer les colonnes pour Prophet
        if 'date' in df.columns:
            df = df.rename(columns={'date': 'ds', 'total': 'y'})
        elif 'sale_date' in df.columns:
            df = df.rename(columns={'sale_date': 'ds', 'total_amount': 'y'})

        # Convertir ds en datetime
        df['ds'] = pd.to_datetime(df['ds'])

        # Agréger par jour si nécessaire (plusieurs ventes par jour)
        df = df.groupby('ds')['y'].sum().reset_index()

        # Trier par date
        df = df.sort_values('ds')

        self.training_data = df
        return df

    def train(self, df=None, yearly_seasonality=True,
              weekly_seasonality=True, daily_seasonality=False):
        """
        Entraîner le modèle Prophet.
        
        Args:
            df: DataFrame préparé (si None, utilise self.training_data)
            yearly_seasonality: Prendre en compte la saisonnalité annuelle
            weekly_seasonality: Prendre en compte la saisonnalité hebdomadaire
            daily_seasonality: Prendre en compte la saisonnalité quotidienne
            
        Returns:
            Le modèle entraîné
        """
        if df is None:
            df = self.training_data

        if df is None or len(df) < 30:
            raise ValueError(
                "Données insuffisantes pour l'entraînement. "
                "Minimum 30 jours de données requis."
            )

        # Configuration du modèle Prophet
        self.model = Prophet(
            yearly_seasonality=yearly_seasonality,
            weekly_seasonality=weekly_seasonality,
            daily_seasonality=daily_seasonality,
            interval_width=0.95,  # Intervalle de confiance à 95%
            changepoint_prior_scale=0.05,  # Flexibilité des changements de tendance
        )

        # Ajouter des saisonnalités personnalisées pour le contexte sénégalais
        # (Ramadan, Tabaski, etc. - fêtes musulmanes impactant les ventes)
        self.model.add_seasonality(
            name='monthly',
            period=30.5,
            fourier_order=5
        )

        # Entraînement
        self.model.fit(df)
        self.is_trained = True

        logger.info(f"Modèle entraîné avec {len(df)} points de données")
        return self.model

    def predict(self, days=30):
        """
        Générer les prédictions pour les N prochains jours.
        
        Args:
            days: Nombre de jours à prédire (défaut: 30)
            
        Returns:
            DataFrame avec les prédictions (ds, yhat, yhat_lower, yhat_upper)
        """
        if not self.is_trained:
            raise ValueError("Le modèle doit être entraîné avant de prédire.")

        # Créer un DataFrame de dates futures
        future = self.model.make_future_dataframe(periods=days, freq='D')

        # Générer les prédictions
        self.forecast = self.model.predict(future)

        # Extraire uniquement les prédictions futures
        future_forecast = self.forecast[
            self.forecast['ds'] > self.training_data['ds'].max()
        ][['ds', 'yhat', 'yhat_lower', 'yhat_upper']]

        logger.info(f"Prédiction générée pour {days} jours")
        return future_forecast

    def predict_for_product(self, product_sales_data, days=30):
        """
        Prédire les ventes pour un produit spécifique.
        
        Args:
            product_sales_data: Données de vente du produit
            days: Nombre de jours à prédire
            
        Returns:
            Dict avec les prédictions et métriques
        """
        # Préparer les données
        df = self.prepare_data(product_sales_data)

        # Créer un nouveau modèle pour ce produit
        product_model = Prophet(
            yearly_seasonality=True,
            weekly_seasonality=True,
            interval_width=0.95
        )
        product_model.fit(df)

        # Prédire
        future = product_model.make_future_dataframe(periods=days)
        forecast = product_model.predict(future)

        future_forecast = forecast[
            forecast['ds'] > df['ds'].max()
        ][['ds', 'yhat', 'yhat_lower', 'yhat_upper']]

        # Calculer les métriques
        metrics = self._calculate_metrics(forecast, df)

        return {
            'forecast': future_forecast,
            'metrics': metrics,
            'trend': forecast[['ds', 'trend']].tail(days).to_dict('records'),
            'recommendation': self._generate_recommendation(
                future_forecast, df
            )
        }

    def evaluate(self, cv_periods=5, cv_horizon='30 days',
                 cv_initial='180 days'):
        """
        Évaluer la performance du modèle avec validation croisée.
        
        Args:
            cv_periods: Nombre de périodes de validation croisée
            cv_horizon: Horizon de prédiction pour chaque période
            cv_initial: Taille minimale des données d'entraînement
            
        Returns:
            Dict avec les métriques de performance
        """
        if not self.is_trained:
            raise ValueError("Le modèle doit être entraîné avant l'évaluation.")

        # Validation croisée
        cv_results = cross_validation(
            self.model,
            initial=cv_initial,
            period=cv_horizon,
            horizon=cv_horizon
        )

        # Calculer les métriques
        metrics = performance_metrics(cv_results)

        return {
            'mape': metrics['mape'].mean(),  # Mean Absolute Percentage Error
            'rmse': metrics['rmse'].mean(),  # Root Mean Squared Error
            'mae': metrics['mae'].mean(),    # Mean Absolute Error
            'coverage': metrics['coverage'].mean(),  # Couverture de l'intervalle
            'metrics_detail': metrics.to_dict('records')
        }

    def _calculate_metrics(self, forecast, actual):
        """Calculer les métriques de performance"""
        # Fusionner prédictions et données réelles
        merged = forecast.merge(actual, on='ds', how='inner')

        if len(merged) == 0:
            return {'mape': 0, 'rmse': 0, 'mae': 0}

        # MAPE (Mean Absolute Percentage Error)
        mape = np.mean(np.abs(
            (merged['y'] - merged['yhat']) / merged['y']
        )) * 100

        # RMSE (Root Mean Squared Error)
        rmse = np.sqrt(np.mean((merged['y'] - merged['yhat']) ** 2))

        # MAE (Mean Absolute Error)
        mae = np.mean(np.abs(merged['y'] - merged['yhat']))

        return {
            'mape': round(mape, 2),
            'rmse': round(rmse, 2),
            'mae': round(mae, 2),
        }

    def _generate_recommendation(self, forecast, historical_data):
        """
        Générer des recommandations basées sur les prédictions.
        
        Retourne des conseils d'approvisionnement basés sur la tendance
        des ventes prédites.
        """
        if len(forecast) == 0:
            return "Données insuffisantes pour générer une recommandation."

        avg_predicted = forecast['yhat'].mean()
        avg_historical = historical_data['y'].mean()

        # Tendance
        if avg_predicted > avg_historical * 1.1:
            trend = "hausse"
            recommendation = (
                f"📈 Tendance à la HAUSSE détectée. "
                f"Ventes prévues : {avg_predicted:.0f} unités/jour. "
                f"Recommandation : Augmenter le stock de sécurité de 15-20%."
            )
        elif avg_predicted < avg_historical * 0.9:
            trend = "baisse"
            recommendation = (
                f"📉 Tendance à la BAISSE détectée. "
                f"Ventes prévues : {avg_predicted:.0f} unités/jour. "
                f"Recommandation : Réduire les commandes de 10-15%."
            )
        else:
            trend = "stable"
            recommendation = (
                f"📊 Tendance STABLE. "
                f"Ventes prévues : {avg_predicted:.0f} unités/jour. "
                f"Recommandation : Maintenir le niveau de stock actuel."
            )

        # Détection de pics
        max_day = forecast.loc[forecast['yhat'].idxmax()]
        if max_day['yhat'] > avg_predicted * 1.5:
            recommendation += (
                f"\n⚠️ PIC PRÉVU le {max_day['ds'].strftime('%d/%m/%Y')} : "
                f"{max_day['yhat']:.0f} unités. "
                f"Prévoir un approvisionnement supplémentaire."
            )

        return {
            'trend': trend,
            'avg_predicted': round(avg_predicted, 2),
            'avg_historical': round(avg_historical, 2),
            'recommendation': recommendation
        }

    def get_stock_alerts(self, current_stock, forecast, threshold_days=7):
        """
        Générer des alertes de stock basées sur les prédictions.
        
        Args:
            current_stock: Stock actuel du produit
            forecast: DataFrame de prédictions
            threshold_days: Nombre de jours pour évaluer le risque
            
        Returns:
            Liste d'alertes avec niveau de risque
        """
        alerts = []

        if len(forecast) < threshold_days:
            return alerts

        # Somme des ventes prévues sur les N prochains jours
        predicted_consumption = forecast.head(threshold_days)['yhat'].sum()

        if current_stock <= 0:
            alerts.append({
                'level': 'CRITICAL',
                'message': '🚨 RUPTURE DE STOCK - Approvisionnement urgent requis !',
                'days_of_stock': 0,
                'action': 'COMMANDER_IMMEDIATEMENT'
            })
        elif current_stock < predicted_consumption * 0.5:
            days_of_stock = current_stock / (
                forecast.head(threshold_days)['yhat'].mean() + 1
            )
            alerts.append({
                'level': 'HIGH',
                'message': f'⚠️ Stock critique ! Seulement {days_of_stock:.0f} jours de stock restants.',
                'days_of_stock': round(days_of_stock),
                'action': 'COMMANDER_URGENT'
            })
        elif current_stock < predicted_consumption:
            days_of_stock = current_stock / (
                forecast.head(threshold_days)['yhat'].mean() + 1
            )
            alerts.append({
                'level': 'MEDIUM',
                'message': f'⚡ Stock faible. Environ {days_of_stock:.0f} jours de stock restants.',
                'days_of_stock': round(days_of_stock),
                'action': 'PLANIFIER_COMMANDE'
            })
        else:
            days_of_stock = current_stock / (
                forecast.head(threshold_days)['yhat'].mean() + 1
            )
            alerts.append({
                'level': 'LOW',
                'message': f'✅ Stock suffisant. Environ {days_of_stock:.0f} jours de stock restants.',
                'days_of_stock': round(days_of_stock),
                'action': 'AUCUNE'
            })

        return alerts


# ==================== UTILITAIRE ====================

def generate_sample_data(days=365, base_sales=50000, volatility=0.2):
    """
    Générer des données de ventes synthétiques pour les tests.
    
    Simule les ventes d'une PME sénégalaise de distribution
    agroalimentaire avec saisonnalité et tendance.
    
    Args:
        days: Nombre de jours de données
        base_sales: Ventes moyennes journalières (FCFA)
        volatility: Variabilité des ventes
        
    Returns:
        DataFrame avec dates et montants de ventes
    """
    np.random.seed(42)
    dates = pd.date_range(end=datetime.now(), periods=days, freq='D')

    # Tendance linéaire (croissance de 5% par an)
    trend = np.linspace(base_sales * 0.95, base_sales * 1.05, days)

    # Saisonnalité hebdomadaire (plus de ventes le week-end)
    weekday_effect = np.array([
        0.9, 0.85, 0.8, 0.85, 1.0, 1.3, 1.2  # Lun-Dim
    ])
    weekly_pattern = np.tile(weekday_effect, days // 7 + 1)[:days]

    # Saisonnalité mensuelle (fin de mois = plus de ventes, salaire)
    monthly_pattern = np.array([
        0.7, 0.75, 0.8, 0.85, 0.9, 0.95, 0.95, 1.0, 1.0, 1.05,
        1.1, 1.15, 1.2, 1.25, 1.3, 1.3, 1.2, 1.1, 1.0, 0.95,
        0.9, 0.85, 0.8, 0.85, 0.9, 0.95, 1.0, 1.05, 1.1, 1.2
    ])
    monthly_effect = np.tile(monthly_pattern, days // 30 + 1)[:days]

    # Bruit aléatoire
    noise = np.random.normal(1, volatility, days)

    # Combinaison
    sales = trend * weekly_pattern * monthly_effect * noise
    sales = np.maximum(sales, 0)  # Pas de ventes négatives

    df = pd.DataFrame({
        'ds': dates,
        'y': sales.astype(int)
    })

    return df


# ==================== TEST RAPIDE ====================

if __name__ == "__main__":
    print("=" * 60)
    print("SmartStock Sénégal - Module de Prédiction IA")
    print("=" * 60)

    # Générer des données de test
    print("\n📊 Génération de données synthétiques...")
    data = generate_sample_data(days=365)
    print(f"   → {len(data)} jours de données générés")
    print(f"   → Période : {data['ds'].min().date()} → {data['ds'].max().date()}")

    # Initialiser le prédicteur
    predictor = SalesPredictor()

    # Préparer les données
    print("\n🔄 Préparation des données...")
    df = predictor.prepare_data(data)

    # Entraîner le modèle
    print("\n🧠 Entraînement du modèle Prophet...")
    predictor.train(df)

    # Prédire
    print("\n🔮 Génération des prédictions (30 jours)...")
    forecast = predictor.predict(days=30)
    print(f"   → {len(forecast)} prédictions générées")
    print(f"   → Première prédiction : {forecast.iloc[0]['ds'].date()}")
    print(f"   → Dernière prédiction : {forecast.iloc[-1]['ds'].date()}")
    print(f"   → Vente moyenne prédite : {forecast['yhat'].mean():.0f} FCFA/jour")

    # Alertes de stock
    print("\n⚡ Vérification des alertes de stock...")
    alerts = predictor.get_stock_alerts(
        current_stock=500000,
        forecast=forecast
    )
    for alert in alerts:
        print(f"   [{alert['level']}] {alert['message']}")

    print("\n✅ Test terminé avec succès !")
    print("=" * 60)
