"""
SmartStock Sénégal - Tests Unitaires
Tests pour le module de prédiction (Prophet)
"""
import pytest
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

# Import du module de prédiction
import sys
import os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '../../ml'))
from predictor import SalesPredictor, generate_sample_data


class TestGenerateSampleData:
    """Tests pour la génération de données synthétiques"""

    def test_generate_data_default(self):
        """Test de génération avec paramètres par défaut"""
        df = generate_sample_data()
        assert len(df) == 365
        assert 'ds' in df.columns
        assert 'y' in df.columns
        assert all(df['y'] >= 0)  # Pas de valeurs négatives

    def test_generate_data_custom_days(self):
        """Test avec un nombre de jours personnalisé"""
        df = generate_sample_data(days=100)
        assert len(df) == 100

    def test_generate_data_custom_base(self):
        """Test avec un montant de base personnalisé"""
        df = generate_sample_data(base_sales=100000)
        avg_sales = df['y'].mean()
        # La moyenne doit être dans l'ordre de grandeur du base_sales
        assert 50000 < avg_sales < 200000

    def test_generate_data_reproducible(self):
        """Test de la reproductibilité (même seed)"""
        df1 = generate_sample_data()
        df2 = generate_sample_data()
        pd.testing.assert_frame_equal(df1, df2)


class TestSalesPredictor:
    """Tests pour la classe SalesPredictor"""

    @pytest.fixture
    def predictor(self):
        return SalesPredictor()

    @pytest.fixture
    def sample_data(self):
        return generate_sample_data(days=365)

    def test_prepare_data_from_dataframe(self, predictor, sample_data):
        """Test de préparation des données depuis un DataFrame"""
        df = predictor.prepare_data(sample_data)
        assert 'ds' in df.columns
        assert 'y' in df.columns
        assert len(df) > 0

    def test_prepare_data_from_list(self, predictor):
        """Test de préparation depuis une liste de dicts"""
        data = [
            {'date': '2025-01-01', 'total': 50000},
            {'date': '2025-01-02', 'total': 60000},
            {'date': '2025-01-03', 'total': 55000},
        ]
        df = predictor.prepare_data(data)
        assert len(df) == 3
        assert df['y'].sum() == 165000

    def test_prepare_data_aggregates_by_day(self, predictor):
        """Test d'agrégation des données par jour"""
        data = pd.DataFrame({
            'ds': ['2025-01-01', '2025-01-01', '2025-01-02'],
            'y': [30000, 20000, 50000]
        })
        df = predictor.prepare_data(data)
        # Le 2025-01-01 devrait être agrégé : 30000 + 20000 = 50000
        day1_data = df[df['ds'] == '2025-01-01']
        assert day1_data['y'].sum() == 50000

    def test_train_insufficient_data(self, predictor):
        """Test d'entraînement avec données insuffisantes"""
        data = generate_sample_data(days=10)
        df = predictor.prepare_data(data)
        with pytest.raises(ValueError, match="Données insuffisantes"):
            predictor.train(df)

    def test_train_success(self, predictor, sample_data):
        """Test d'entraînement réussi"""
        df = predictor.prepare_data(sample_data)
        model = predictor.train(df)
        assert predictor.is_trained is True
        assert model is not None

    def test_predict_before_training(self, predictor):
        """Test de prédiction avant entraînement"""
        with pytest.raises(ValueError, match="doit être entraîné"):
            predictor.predict(days=30)

    def test_predict_success(self, predictor, sample_data):
        """Test de prédiction réussie"""
        df = predictor.prepare_data(sample_data)
        predictor.train(df)
        forecast = predictor.predict(days=30)

        assert len(forecast) == 30
        assert 'ds' in forecast.columns
        assert 'yhat' in forecast.columns
        assert 'yhat_lower' in forecast.columns
        assert 'yhat_upper' in forecast.columns

        # Les prédictions doivent être positives
        assert all(forecast['yhat'] >= 0)
        # Les bornes inférieures < yhat < bornes supérieures
        assert all(forecast['yhat_lower'] <= forecast['yhat'])
        assert all(forecast['yhat'] <= forecast['yhat_upper'])

    def test_predict_different_horizons(self, predictor, sample_data):
        """Test de prédiction sur différentes durées"""
        df = predictor.prepare_data(sample_data)
        predictor.train(df)

        for days in [7, 14, 30, 60]:
            forecast = predictor.predict(days=days)
            assert len(forecast) == days

    def test_evaluate(self, predictor, sample_data):
        """Test de l'évaluation du modèle"""
        df = predictor.prepare_data(sample_data)
        predictor.train(df)
        metrics = predictor.evaluate(
            cv_periods=3,
            cv_horizon='30 days',
            cv_initial='180 days'
        )

        assert 'mape' in metrics
        assert 'rmse' in metrics
        assert 'mae' in metrics
        assert metrics['mape'] >= 0
        assert metrics['rmse'] >= 0

    def test_stock_alerts_critical(self, predictor, sample_data):
        """Test d'alerte CRITIQUE (stock = 0)"""
        df = predictor.prepare_data(sample_data)
        predictor.train(df)
        forecast = predictor.predict(days=7)

        alerts = predictor.get_stock_alerts(
            current_stock=0,
            forecast=forecast,
            threshold_days=7
        )
        assert len(alerts) > 0
        assert alerts[0]['level'] == 'CRITICAL'

    def test_stock_alerts_sufficient(self, predictor, sample_data):
        """Test d'alerte LOW (stock suffisant)"""
        df = predictor.prepare_data(sample_data)
        predictor.train(df)
        forecast = predictor.predict(days=7)

        alerts = predictor.get_stock_alerts(
            current_stock=10000000,  # Stock très élevé
            forecast=forecast,
            threshold_days=7
        )
        assert len(alerts) > 0
        assert alerts[0]['level'] == 'LOW'

    def test_stock_alerts_high(self, predictor, sample_data):
        """Test d'alerte HIGH (stock faible)"""
        df = predictor.prepare_data(sample_data)
        predictor.train(df)
        forecast = predictor.predict(days=7)

        alerts = predictor.get_stock_alerts(
            current_stock=100,  # Stock très bas
            forecast=forecast,
            threshold_days=7
        )
        assert len(alerts) > 0
        # Niveau HIGH ou MEDIUM selon la consommation prédite
        assert alerts[0]['level'] in ['HIGH', 'MEDIUM']


class TestPredictionRecommendations:
    """Tests pour les recommandations générées"""

    def test_recommendation_format(self):
        """Test du format des recommandations"""
        predictor = SalesPredictor()
        data = generate_sample_data(days=365)
        df = predictor.prepare_data(data)
        predictor.train(df)

        result = predictor.predict_for_product(data, days=30)

        assert 'forecast' in result
        assert 'metrics' in result
        assert 'recommendation' in result
        assert 'trend' in result['recommendation']

    def test_recommendation_content(self):
        """Test du contenu des recommandations"""
        predictor = SalesPredictor()
        data = generate_sample_data(days=365)
        df = predictor.prepare_data(data)
        predictor.train(df)

        result = predictor.predict_for_product(data, days=30)
        rec = result['recommendation']

        # La recommandation doit mentionner la tendance
        assert rec['trend'] in ['hausse', 'baisse', 'stable']
        # Les valeurs moyennes doivent être positives
        assert rec['avg_predicted'] > 0
        assert rec['avg_historical'] > 0


if __name__ == '__main__':
    pytest.main([__file__, '-v'])
