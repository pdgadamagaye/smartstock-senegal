# 📊 DIAGRAMMES UML & MERISE
## Système SmartStock — Cas d'étude : CDA

---

## 1. MODÈLE CONCEPTUEL DE DONNÉES (MCD)

| Entité | Attributs principaux | Relations |
|--------|---------------------|-----------|
| **CATEGORIE** | id, nom, description | 1,N → PRODUIT |
| **PRODUIT** | id, nom, référence, prix_achat, prix_vente, seuil_min | N,1 → CATEGORIE \| 1,N → MOUVEMENT_STOCK \| 1,N → LIGNE_VENTE |
| **MOUVEMENT_STOCK** | id, type (IN/OUT), quantité, motif, date | N,1 → PRODUIT \| N,1 → UTILISATEUR |
| **CLIENT** | id, nom, téléphone, email, type, ville | 1,N → VENTE |
| **VENTE** | id, référence, date, montant_total, statut, paiement | 1,N → LIGNE_VENTE \| N,1 → CLIENT |
| **LIGNE_VENTE** | id, quantité, prix_unitaire, remise | N,1 → VENTE \| N,1 → PRODUIT |
| **PREDICTION** | id, date, valeur_predite, borne_inf, borne_sup | N,1 → PRODUIT |
| **ALERTE_STOCK** | id, niveau, message, lu? | N,1 → PRODUIT |

---

## 2. DIAGRAMME DE CAS D'UTILISATION

| Acteur | Cas d'utilisation | Description |
|--------|-------------------|-------------|
| **Gérant** | Voir tableau de bord | KPIs en temps réel |
| **Gérant** | Gérer les produits | CRUD produits et catégories |
| **Gérant** | Voir les prédictions IA | Prédictions des 4 modèles |
| **Gérant** | Configurer les alertes | Seuils et canaux |
| **Gérant** | Générer rapports | Rapports PDF automatiques |
| **Vendeur** | Enregistrer une vente | Saisie des ventes |
| **Vendeur** | Gérer les clients | CRUD clients |
| **Vendeur** | Consulter le stock | Vérifier niveaux |
| **Magasinier** | Mouvement de stock | Entrées/sorties |
| **Magasinier** | Recevoir alertes stock | Notifications in-app |

---

## 3. DIAGRAMME DE CLASSES

| Classe | Attributs | Méthodes principales |
|--------|-----------|---------------------|
| **Product** | id, name, reference, purchase_price, selling_price, unit, min_stock_threshold | current_stock(), is_low_stock(), profit_margin() |
| **Category** | id, name, description | get_products() |
| **Sale** | id, reference, sale_date, payment_method, status, total_amount | calculate_total(), add_item() |
| **SaleItem** | id, quantity, unit_price, discount | subtotal() |
| **Client** | id, name, phone, email, client_type | total_purchases(), number_of_purchases() |
| **SalesPredictor** | model, is_trained, training_data | prepare_data(), train(), predict(), evaluate() |
| **PDFReportGenerator** | company_name, output_dir | generate_daily_report(), generate_monthly_report() |

---

## 4. SÉQUENCE — Enregistrer une vente

| # | Acteur | Action |
|---|--------|--------|
| 1 | Vendeur (React) | POST /api/sales/ |
| 2 | API Django | Valide les données (serializer) |
| 3 | API Django | INSERT INTO sales |
| 4 | API Django | INSERT INTO sale_items |
| 5 | API Django | UPDATE stock (décrémenter) |
| 6 | API Django | Vérifie : Stock < Seuil ? |
| 7 | Module IA | Si oui → predict(product_id, days=7) |
| 8 | Module Alertes | Génère alerte + recommandation |
| 9 | Notifications | Notification in-app |
| 10 | API Django | 201 Created |

---

## 5. SÉQUENCE — Prédiction des ventes

| # | Acteur | Action |
|---|--------|--------|
| 1 | Utilisateur | GET /api/predictions/?product=1&days=30 |
| 2 | API Django | Récupère données historiques |
| 3 | Module IA | Prépare données (format Prophet) |
| 4 | Module IA | Entraîne les 4 modèles |
| 5 | Module IA | Calcule métriques (MAPE, RMSE, MAE) |
| 6 | Module IA | Sélectionne le meilleur modèle |
| 7 | Module IA | Génère prédictions 30 jours |
| 8 | Module IA | Génère recommandations |
| 9 | API Django | Stocke en base |
| 10 | Utilisateur | Affiche graphique Chart.js |

---

## 6. ACTIVITÉ — Gestion des alertes

| Étape | Action | Condition |
|-------|--------|-----------|
| 1 | Vérifier stock tous les produits | Périodicité : 1h |
| 2 | Stock ≤ Seuil ? | Si Non → produit suivant |
| 3 | Données historiques ? | Si Non → alerte basique |
| 4 | Exécuter 4 modèles | Prophet sur 7 jours |
| 5 | Rupture prédite 7j ? | Si Oui → CRITIQUE |
| 6 | Générer recommandation | Quantité + délai |
| 7 | Notification in-app | Tableau de bord |
| 8 | Enregistrer alerte | INSERT INTO alertes |
| 9 | Produit suivant | Boucle |

---

## 7. DÉPLOIEMENT

| Composant | Technologie | Localisation | Rôle |
|-----------|-------------|-------------|------|
| Client | Navigateur web | Poste utilisateur | Accès dashboard |
| Frontend | React.js + Chart.js | Serveur web | Interface |
| Backend API | Django 5.0 + DRF | Serveur applicatif | Logique métier |
| Module IA | Python (Prophet, statsmodels) | Serveur applicatif | Prédiction |
| Module Reporting | ReportLab + Pandas | Serveur applicatif | Génération PDF |
| BDD | PostgreSQL 15 | Serveur dédié | Stockage |
| Hosting | Railway / Render | Cloud gratuit | Infrastructure |

---

## 8. ARCHITECTURE GÉNÉRALE

| Pilier | Composants | Technologies | Fonction |
|--------|-----------|-------------|----------|
| 🧠 PRÉDICTION IA | SMA, Holt-Winters, SARIMA, Prophet | Python, statsmodels, Prophet | Prévision 7/14/30 jours |
| 📊 TABLEAU DE BORD | KPI Cards, Graphiques, Alertes | React.js, Chart.js, Axios | Visualisation temps réel |
| 📄 REPORTING AUTO | Rapports journaliers, mensuels | ReportLab, Pandas, Django | Génération + envoi |
| ⚙️ BACKEND | API REST, Auth JWT, Permissions | Django 5.0, DRF | Logique métier |
| 💾 DONNÉES | Produits, Ventes, Clients, Stocks | PostgreSQL | Persistance |
