/**
 * SmartStock Sénégal - Frontend React
 * Application principale
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider } from './context/AuthContext';

// Layout
import Navbar from './components/Layout/Navbar';
import Sidebar from './components/Layout/Sidebar';

// Pages
import Dashboard from './components/Dashboard/Dashboard';
import ProductList from './components/Products/ProductList';
import SalesList from './components/Sales/SalesList';
import StockLevel from './components/Inventory/StockLevel';
import PredictionChart from './components/Predictions/PredictionChart';

import './styles/App.css';

function App() {
  return (
    <AuthProvider>
      <Router>
        <div className="app-container">
          <Sidebar />
          <div className="main-content">
            <Navbar />
            <div className="page-content">
              <Routes>
                <Route path="/" element={<Dashboard />} />
                <Route path="/produits" element={<ProductList />} />
                <Route path="/ventes" element={<SalesList />} />
                <Route path="/stock" element={<StockLevel />} />
                <Route path="/predictions" element={<PredictionChart />} />
                <Route path="*" element={<Navigate to="/" />} />
              </Routes>
            </div>
          </div>
        </div>
      </Router>
    </AuthProvider>
  );
}

export default App;
