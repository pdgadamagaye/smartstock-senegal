/**
 * SmartStock Sénégal - Service API
 * Configuration Axios et endpoints
 */

import axios from 'axios';

const API_BASE_URL = process.env.REACT_APP_API_URL || 'http://localhost:8000/api';

// Configuration Axios
const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Intercepteur pour ajouter le token d'authentification
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('access_token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Intercepteur pour gérer les erreurs 401 (token expiré)
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      localStorage.removeItem('access_token');
      window.location.href = '/login';
    }
    return Promise.reject(error);
  }
);

// ==================== DASHBOARD ====================

export const getDashboardData = () => api.get('/dashboard/');
export const getDailySales = (days = 30) => api.get(`/sales/daily_summary/?days=${days}`);
export const getTopProducts = (days = 30) => api.get(`/sales/top_products/?days=${days}`);
export const getPaymentStats = (days = 30) => api.get(`/sales/payment_methods_stats/?days=${days}`);

// ==================== PRODUITS ====================

export const getProducts = (params = {}) => api.get('/products/', { params });
export const getProduct = (id) => api.get(`/products/${id}/`);
export const createProduct = (data) => api.post('/products/', data);
export const updateProduct = (id, data) => api.patch(`/products/${id}/`, data);
export const deleteProduct = (id) => api.delete(`/products/${id}/`);
export const addStock = (id, quantity, reason) => api.post(`/products/${id}/add_stock/`, { quantity, reason });
export const getStockHistory = (id) => api.get(`/products/${id}/stock_history/`);

// ==================== CATÉGORIES ====================

export const getCategories = () => api.get('/categories/');
export const createCategory = (data) => api.post('/categories/', data);

// ==================== VENTES ====================

export const getSales = (params = {}) => api.get('/sales/', { params });
export const getSale = (id) => api.get(`/sales/${id}/`);
export const createSale = (data) => api.post('/sales/', data);

// ==================== CLIENTS ====================

export const getClients = () => api.get('/clients/');
export const getClient = (id) => api.get(`/clients/${id}/`);
export const createClient = (data) => api.post('/clients/', data);
export const updateClient = (id, data) => api.patch(`/clients/${id}/`, data);

// ==================== PREDICTIONS ====================

export const getPredictions = (productId, days = 30) =>
  api.get(`/predictions/?product=${productId}&days=${days}`);
export const getStockAlerts = () => api.get('/inventory/alerts/');
export const runPrediction = (productId, days = 30) =>
  api.post('/predictions/run/', { product_id: productId, days });

// ==================== AUTHENTIFICATION ====================

export const login = (username, password) =>
  api.post('/auth/login/', { username, password });
export const logout = () => api.post('/auth/logout/');
export const getCurrentUser = () => api.get('/auth/user/');

export default api;
