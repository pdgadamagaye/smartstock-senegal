/**
 * SmartStock Sénégal - Composant Dashboard
 * Tableau de bord principal avec KPIs et graphiques
 */

import React, { useState, useEffect } from 'react';
import { Line, Bar, Doughnut } from 'react-chartjs-2';
import {
  Chart as ChartJS,
  CategoryScale,
  LinearScale,
  PointElement,
  LineElement,
  BarElement,
  ArcElement,
  Title,
  Tooltip,
  Legend,
  Filler,
} from 'chart.js';
import { getDashboardData, getDailySales, getTopProducts } from '../../services/api';
import KPICard from './KPICard';

// Enregistrer les composants Chart.js
ChartJS.register(
  CategoryScale, LinearScale, PointElement, LineElement,
  BarElement, ArcElement, Title, Tooltip, Legend, Filler
);

function Dashboard() {
  const [dashboardData, setDashboardData] = useState(null);
  const [dailySales, setDailySales] = useState([]);
  const [topProducts, setTopProducts] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadDashboardData();
  }, []);

  const loadDashboardData = async () => {
    try {
      setLoading(true);
      const [dashRes, salesRes, topRes] = await Promise.all([
        getDashboardData(),
        getDailySales(30),
        getTopProducts(30)
      ]);

      setDashboardData(dashRes.data);
      setDailySales(salesRes.data);
      setTopProducts(topRes.data);
    } catch (error) {
      console.error('Erreur chargement dashboard:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return (
      <div className="loading-container">
        <div className="spinner"></div>
        <p>Chargement du tableau de bord...</p>
      </div>
    );
  }

  // Configuration du graphique des ventes quotidiennes
  const salesChartData = {
    labels: dailySales.map(item =>
      new Date(item.sale_date__date).toLocaleDateString('fr-FR', { day: '2-digit', month: 'short' })
    ),
    datasets: [
      {
        label: 'Ventes (FCFA)',
        data: dailySales.map(item => item.total_revenue),
        borderColor: '#1a73e8',
        backgroundColor: 'rgba(26, 115, 232, 0.1)',
        fill: true,
        tension: 0.4,
      },
      {
        label: 'Nombre de ventes',
        data: dailySales.map(item => item.count),
        borderColor: '#34a853',
        backgroundColor: 'rgba(52, 168, 83, 0.1)',
        fill: false,
        tension: 0.4,
        yAxisID: 'y1',
      },
    ],
  };

  // Configuration du graphique top produits
  const topProductsChart = {
    labels: topProducts.map(p => p.product__name?.substring(0, 15) + '...'),
    datasets: [{
      label: 'Revenus (FCFA)',
      data: topProducts.map(p => p.total_revenue),
      backgroundColor: [
        '#1a73e8', '#34a853', '#fbbc04', '#ea4335',
        '#673ab7', '#ff9800', '#00bcd4', '#e91e63',
        '#9c27b0', '#4caf50'
      ],
    }],
  };

  // Formatage des montants en FCFA
  const formatFCFA = (amount) => {
    return new Intl.NumberFormat('fr-FR', {
      style: 'decimal',
      minimumFractionDigits: 0
    }).format(amount) + ' FCFA';
  };

  return (
    <div className="dashboard">
      <div className="page-header">
        <h1>📊 Tableau de Bord</h1>
        <p className="subtitle">Vue d'ensemble de votre activité commerciale</p>
      </div>

      {/* KPI Cards */}
      <div className="kpi-grid">
        <KPICard
          title="Chiffre d'affaires (Aujourd'hui)"
          value={formatFCFA(dashboardData?.revenue_today || 0)}
          icon="💰"
          color="#1a73e8"
          trend="+12%"
        />
        <KPICard
          title="Ventes totales"
          value={dashboardData?.total_sales || 0}
          icon="🛒"
          color="#34a853"
        />
        <KPICard
          title="Produits en stock"
          value={dashboardData?.total_products || 0}
          icon="📦"
          color="#fbbc04"
        />
        <KPICard
          title="Clients actifs"
          value={dashboardData?.total_clients || 0}
          icon="👥"
          color="#673ab7"
        />
        <KPICard
          title="Alertes stock"
          value={dashboardData?.low_stock_count || 0}
          icon="⚠️"
          color="#ea4335"
        />
      </div>

      {/* Graphiques */}
      <div className="charts-grid">
        {/* Graphique des ventes quotidiennes */}
        <div className="chart-card wide">
          <h3>📈 Évolution des ventes (30 derniers jours)</h3>
          <Line
            data={salesChartData}
            options={{
              responsive: true,
              plugins: {
                legend: { position: 'top' },
                title: { display: false },
              },
              scales: {
                y: {
                  type: 'linear',
                  display: true,
                  position: 'left',
                  title: { display: true, text: 'Montant (FCFA)' }
                },
                y1: {
                  type: 'linear',
                  display: true,
                  position: 'right',
                  title: { display: true, text: 'Nombre de ventes' },
                  grid: { drawOnChartArea: false },
                },
              },
            }}
          />
        </div>

        {/* Graphique top produits */}
        <div className="chart-card">
          <h3>🏆 Top 10 Produits</h3>
          <Bar
            data={topProductsChart}
            options={{
              responsive: true,
              indexAxis: 'y',
              plugins: {
                legend: { display: false },
              },
            }}
          />
        </div>

        {/* Ventes récentes */}
        <div className="chart-card">
          <h3>🕐 Ventes récentes</h3>
          <table className="recent-sales-table">
            <thead>
              <tr>
                <th>Référence</th>
                <th>Montant</th>
                <th>Date</th>
                <th>Statut</th>
              </tr>
            </thead>
            <tbody>
              {dashboardData?.recent_sales?.map(sale => (
                <tr key={sale.id}>
                  <td>{sale.reference}</td>
                  <td>{formatFCFA(sale.total_amount)}</td>
                  <td>{new Date(sale.sale_date).toLocaleDateString('fr-FR')}</td>
                  <td>
                    <span className={`badge badge-${sale.status}`}>
                      {sale.status}
                    </span>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}

export default Dashboard;
