# 📁 STRUCTURE DU DÉPÔT GITHUB

```
smartstock-senegal/
│
├── 📘 00_SUIVI_ETAPES.md          ← Tableau de bord de suivi quotidien
├── 📄 01_fiche_sujet.pdf          ← Fiche sujet officielle (à imprimer)
├── 📄 02_plan_memoire.pdf         ← Plan détaillé du mémoire
├── 📧 03_email_contact_cda.md     ← Contact CDA (email + script)
├── 📁 04_structure_github.md      ← Ce fichier
├── 📅 05_plan_action_detaille.md  ← Plan d'action jour par jour
├── 📖 README.md                   ← Présentation du projet
│
├── 🐍 backend/                    ← Django REST API
│   ├── requirements.txt
│   └── apps/
│       ├── products/
│       │   ├── models.py          ← Product, Category, StockMovement
│       │   ├── serializers.py     ← Sérialiseurs DRF
│       │   ├── views.py           ← ViewSets + filtres
│       │   └── tests/
│       │       └── test_models.py ← Tests unitaires
│       ├── sales/
│       │   ├── models.py          ← Sale, SaleItem, Client
│       │   └── views.py           ← Ventes + dashboard + KPIs
│       ├── notifications/
│       │   └── services.py        ← SMS + Email + Alertes
│       └── reporting/
│           └── services.py        ← PDF (ReportLab) + Excel (Pandas)
│
├── 🎨 frontend/                   ← React.js
│   ├── package.json
│   └── src/
│       ├── App.js                 ← Application principale
│       ├── components/
│       │   └── Dashboard/
│       │       └── Dashboard.js   ← Tableau de bord + Chart.js
│       └── services/
│           └── api.js             ← Service API Axios
│
├── 🧠 ml/                         ← Module IA
│   ├── model_comparison.py        ← Comparaison 4 modèles ⭐
│   ├── predictor.py               ← Module Prophet complet
│   └── tests/
│       └── test_predictor.py      ← 15+ tests unitaires
│
└── 📊 docs/
    └── diagrams/
        └── diagrams_mermaid.md    ← 8 diagrammes UML/Merise
```

## 🚀 INSTALLATION RAPIDE

```bash
# Cloner le dépôt
git clone https://github.com/adama-gaye/smartstock-senegal.git
cd smartstock-senegal

# Backend
cd backend
pip install -r requirements.txt
python manage.py migrate
python manage.py runserver

# Frontend
cd frontend
npm install
npm start

# Module IA (comparaison 4 modèles)
cd ml
pip install -r requirements.txt
python model_comparison.py
```

## 📊 LES 4 MODÈLES COMPARÉS

| # | Modèle | Type | Rôle |
|---|--------|------|------|
| 1 | Moyenne Mobile (SMA) | Baseline | Référence minimale |
| 2 | Holt-Winters | Exponential Smoothing | Tendance + saisonnalité |
| 3 | SARIMA | ARIMA saisonnier | Rigueur statistique |
| 4 | Prophet | Facebook ML | Variables culturelles (Ramadan, Tabaski) |
