# 📚 PLAN DÉTAILLÉ DU MÉMOIRE

**Système d'Aide à la Décision : IA + Tableau de Bord + Reporting Automatisé**  
**Cas d'étude : CDA — Chaîne de Distribution Alimentaire**

---

DEDICACES  
REMERCIEMENTS  
LISTE DES ABRÉVIATIONS  
LISTE DES FIGURES  
LISTE DES TABLEAUX  
RÉSUMÉ (FR / EN)

---

## INTRODUCTION GÉNÉRALE (pp. 1-10)

1. Contexte
   - Les PME sénégalaises face à la digitalisation
   - Les 3 défis : prévision, pilotage, reporting
   - La CDA comme cas d'étude
2. Problématique
3. Objectifs (général + 7 spécifiques)
4. Hypothèses de recherche
5. Méthodologie
6. Annonce du plan

---

## CHAPITRE 1 : REVUE DE LITTÉRATURE (pp. 11-30)

### 1.1 Les systèmes d'aide à la décision (SAD)
- Définition et historique
- Composants d'un SAD (données, modèles, interface)
- SAD dans les PME : état de l'art

### 1.2 La prévision des ventes par l'IA
- Les séries temporelles : composantes (tendance, saisonnalité, résidus)
- **Modèle 1 :** Moyenne Mobile (SMA) — baseline, simplicité et limites
- **Modèle 2 :** Holt-Winters (Exponential Smoothing) — tendance + saisonnalité
- **Modèle 3 :** SARIMA — rigueur statistique, autocorrélation
- **Modèle 4 :** Prophet (Facebook) — saisonnalités multiples, variables exogènes
- Tableau comparatif des 4 modèles (forces, faiblesses, cas d'usage)

### 1.3 Le tableau de bord de pilotage
- Définition et typologie
- KPIs pour la distribution alimentaire
- Technologies web (React, Chart.js, D3.js)

### 1.4 L'automatisation du reporting
- Génération de rapports PDF (ReportLab, WeasyPrint)
- Génération de rapports Excel (Pandas, openpyxl)
- Planification et automatisation (Celery, cron)

### 1.5 Le contexte sénégalais
- Spécificités des PME sénégalaises
- Saisonnalité culturelle (Ramadan, Tabaski)
- Lacune identifiée : aucune solution intégrée existante

---

## CHAPITRE 2 : ANALYSE DES BESOINS ET SPÉCIFICATIONS (pp. 31-50)

### 2.1 Présentation de la CDA
- Historique et structure
- Organisation multi-sites (Plateau + Sébikotane)
- Processus actuels (gestion des stocks, reporting)
- Problèmes identifiés (guide d'entretien en annexe)

### 2.2 Spécifications fonctionnelles
- Module 1 : Prédiction des ventes (IA)
- Module 2 : Tableau de bord interactif
- Module 3 : Automatisation du reporting
- Module 4 : Alertes automatiques
- Module 5 : Gestion commerciale (produits, ventes, stocks)

### 2.3 Spécifications non-fonctionnelles
- Performance, sécurité, disponibilité
- Contraintes locales (connexion internet, formation)

### 2.4 Modélisation (Merise + UML)
- MCD / MLD / MPD
- Diagrammes de cas d'utilisation
- Diagrammes de séquence
- Diagramme de classes

---

## CHAPITRE 3 : ÉTUDE COMPARATIVE DES 4 MODÈLES DE PRÉDICTION (pp. 51-72)

> ⭐ **Cœur scientifique — Contribution originale du mémoire**

### 3.1 Protocole expérimental
- Dataset CDA (période, granularité, prétraitement)
- Métriques : MAPE, RMSE, MAE
- Validation croisée temporelle (Time Series Split)

### 3.2 Implémentation des 4 modèles
- **Modèle 1 :** Moyenne Mobile (SMA-7, SMA-30) — baseline simple
- **Modèle 2 :** Holt-Winters (additif, multiplicatif) — saisonnalité classique
- **Modèle 3 :** SARIMA — sélection automatique des paramètres (p,d,q)(P,D,Q,s)
- **Modèle 4 :** Prophet — avec saisonnalités culturelles (Ramadan, Tabaski)

### 3.3 Résultats de la comparaison
- Tableau comparatif final (MAPE, RMSE, MAE pour chaque modèle)
- Graphiques : prédictions vs réel pour chaque modèle
- Analyse par famille de produits (riz, huile, conserves, frais)
- Analyse par horizon de prédiction (7, 14, 30 jours)
- Tests statistiques (Diebold-Mariano)

### 3.4 Impact des variables culturelles
- Ajout de variables Ramadan, Tabaski, saisons dans Prophet
- Amélioration mesurée (comparaison avec/sans variables culturelles)
- **Résultat clé** : quantification de l'impact (+X% de précision)

### 3.5 Sélection du modèle optimal
- Critères : précision, interprétabilité, coût computationnel, robustesse
- Modèle retenu et justification scientifique
- Recommandations pour les PME sénégalaises

---

## CHAPITRE 4 : CONCEPTION DU SYSTÈME (pp. 73-86)

### 4.1 Architecture globale
- Architecture 3-tiers
- Architecture modulaire (5 modules)
- Diagramme de déploiement

### 4.2 Conception du tableau de bord
- Maquettes fonctionnelles
- KPIs sélectionnés (CA, top produits, alertes, tendances)
- Architecture des composants React

### 4.3 Conception du module de reporting
- Templates de rapports (journalier, hebdomadaire, mensuel)
- Format PDF (mise en page, graphiques)
- Planification automatique

### 4.4 Conception de l'API REST
- Endpoints (prédiction, dashboard, reports, alerts)
- Authentification JWT
- Multi-sites

---

## CHAPITRE 5 : IMPLÉMENTATION (pp. 87-108)

### 5.1 Environnement technique

### 5.2 Backend Django (extraits commentés)
- Modèles de données
- API REST (endpoints principaux)
- Module IA intégré
- Module de reporting (ReportLab)

### 5.3 Frontend React
- Tableau de bord interactif
- Page des prédictions
- Page des rapports (téléchargement PDF)
- Page des alertes

### 5.4 Module d'automatisation
- Génération PDF (ReportLab)
- Planification (tâches automatiques)
- Envoi par email

### 5.5 Module d'alertes
- Détection des seuils
- Notifications in-app

---

## CHAPITRE 6 : TESTS ET VALIDATION (pp. 109-122)

### 6.1 Tests techniques
- Tests unitaires (coverage > 90%)
- Tests d'intégration
- Tests de performance

### 6.2 Validation scientifique
- Confirmation/infirmation de H1 (comparaison modèles)
- Confirmation/infirmation de H2 (temps de décision)
- Confirmation/infirmation de H3 (automatisation)

### 6.3 Validation opérationnelle à la CDA
- Mesure du temps économisé (reporting)
- Mesure de la précision des prédictions
- Retour d'expérience des utilisateurs

---

## CONCLUSION GÉNÉRALE (pp. 123-130)

1. Synthèse des résultats
2. Contributions (scientifiques + pratiques)
3. Limites
4. Perspectives
   - Extension à d'autres entreprises
   - Données externes (météo, prix des marchés)
   - Application mobile pour les commerciaux terrain
5. Recommandations pour les PME sénégalaises

---

## BIBLIOGRAPHIE

## ANNEXES
- A : Code de comparaison des modèles
- B : Résultats détaillés des expérimentations
- C : Guide d'entretien CDA
- D : Captures d'écran complètes
- E : Templates de rapports (PDF)
- F : Code source de l'application (extraits)
- G : Accord de collaboration CDA

---

*Total : ~130 pages + annexes*  
*Chapitre 3 (4 modèles comparés) = 22 pages ⭐ Cœur scientifique*  
*Chapitre 5 (Implémentation) = 22 pages*
