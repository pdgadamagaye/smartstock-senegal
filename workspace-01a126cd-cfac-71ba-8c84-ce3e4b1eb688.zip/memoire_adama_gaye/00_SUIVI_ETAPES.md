# 🎯 SUIVI ÉTAPE PAR ÉTAPE — MÉMOIRE ADAMA GAYE

**Projet** : Système d'aide à la décision — CDA  
**Début** : 15 août 2026 | **Soutenance** : Juin 2027  
**Objectif** : Mention Excellente + Félicitations du jury

---

## 📊 AVANCEMENT GLOBAL

```
Phase 0 : Contact CDA          [░░░░░░░░░░] 0%  ← TU ES ICI
Phase 1 : Apprentissage        [░░░░░░░░░░] 0%
Phase 2 : Expérimentation IA   [░░░░░░░░░░] 0%
Phase 3 : Développement        [░░░░░░░░░░] 0%
Phase 4 : Rédaction            [░░░░░░░░░░] 0%
Phase 5 : Soutenance           [░░░░░░░░░░] 0%
```

---

## 🔴 ÉTAPE 0 : PRISE DE CONTACT CDA (15-22 août)

| # | Action | Deadline | Statut |
|---|--------|----------|--------|
| 1 | Imprimer la fiche sujet (PDF) | 15 août | ☐ |
| 2 | Obtenir lettre recommandation UCAO | 15 août | ☐ |
| 3 | Email à M. Karim FILFILI (karimfilfili@cdasenegal.com) | 15 août | ☐ |
| 4 | Appeler CDA (+221 33 823 11 20) | 16 août | ☐ |
| 5 | Visiter le 31 rue du Dr Thèze, Plateau | 17-18 août | ☐ |
| 6 | Obtenir RDV avec la direction | 19 août | ☐ |
| 7 | Entretien : comprendre processus + besoins | 20-21 août | ☐ |
| 8 | Récupérer les premières données de ventes | 21-22 août | ☐ |

**Critère de passage :**
- ☐ Accord écrit/verbal d'un responsable CDA
- ☐ Au moins 3 mois de données de ventes
- ☐ Dépôt GitHub `smartstock-senegal` créé

**Si la CDA ne répond pas avant le 22 août :**
- Plan B : Marché de Tilène ou Colobane — grossiste alimentaire
- Plan C : COSEMAD (+221 33 869 04 40) ou Au Bon Accueil (+221 33 821 74 05)

---

## 🔴 ÉTAPE 1 : APPRENTISSAGE PYTHON + POSTGRESQL (22-28 août)

| # | Action | Ressource | Statut |
|---|--------|-----------|--------|
| 1 | Installer Python 3.11+, VS Code, Git | — | ☐ |
| 2 | Créer GitHub + repo smartstock-senegal | github.com | ☐ |
| 3 | Python : Variables, types, conditions | learnpython.org | ☐ |
| 4 | Python : Boucles, listes, dictionnaires | learnpython.org | ☐ |
| 5 | Python : POO (classes, objets) | learnpython.org | ☐ |
| 6 | Python : Lire/écrire fichiers CSV | docs.python.org | ☐ |
| 7 | Installer PostgreSQL 15 | postgresqltutorial.com | ☐ |
| 8 | SQL : CREATE TABLE, INSERT, SELECT | postgresqltutorial.com | ☐ |
| 9 | SQL : JOIN, GROUP BY, agrégations | postgresqltutorial.com | ☐ |
| 10 | **PROJET** : Script Python + PostgreSQL | — | ☐ |

---

## 🔴 ÉTAPE 2 : APPRENTISSAGE DJANGO (29 août - 4 sept)

| # | Action | Ressource | Statut |
|---|--------|-----------|--------|
| 1 | Installer Django 5.0 | docs.djangoproject.com | ☐ |
| 2 | Créer projet + première app | Tutorial officiel | ☐ |
| 3 | Modèles : Product, Category, StockMovement | — | ☐ |
| 4 | Migrations + Admin Django | — | ☐ |
| 5 | Vues + URLs | — | ☐ |
| 6 | Installer DRF + Serializers | djangorestframework.org | ☐ |
| 7 | API REST : endpoints CRUD produits | — | ☐ |
| 8 | Modèles : Sale, SaleItem, Client | — | ☐ |
| 9 | API REST : endpoints CRUD ventes | — | ☐ |
| 10 | **PROJET** : API complète testée (Postman) | — | ☐ |

---

## 🔴 ÉTAPE 3 : APPRENTISSAGE REACT + TABLEAU DE BORD (5-11 sept)

| # | Action | Ressource | Statut |
|---|--------|-----------|--------|
| 1 | Installer Node.js + créer app React | react.dev/learn | ☐ |
| 2 | Composants, Props, JSX | react.dev/learn | ☐ |
| 3 | useState, useEffect, useContext | react.dev/learn | ☐ |
| 4 | Installer Axios + connecter API Django | — | ☐ |
| 5 | Créer Navbar + Sidebar | — | ☐ |
| 6 | Page Dashboard (KPI Cards) | — | ☐ |
| 7 | Installer Chart.js + graphique | chartjs.org | ☐ |
| 8 | Page Liste des Produits | — | ☐ |
| 9 | Page Liste des Ventes | — | ☐ |
| 10 | **PROJET** : Frontend complet connecté | — | ☐ |

---

## 🔴 ÉTAPE 4 : IA (4 MODÈLES) + REPORTING (12-21 sept)

| # | Action | Statut |
|---|--------|--------|
| 1 | Installer Prophet | ☐ |
| 2 | Comprendre les séries temporelles | ☐ |
| 3 | Implémenter Modèle 1 : Moyenne Mobile (SMA) | ☐ |
| 4 | Implémenter Modèle 2 : Holt-Winters | ☐ |
| 5 | Implémenter Modèle 3 : SARIMA | ☐ |
| 6 | Implémenter Modèle 4 : Prophet (+ culturel) | ☐ |
| 7 | Comparer les 4 modèles (MAPE, RMSE, MAE) | ☐ |
| 8 | Installer ReportLab + premier PDF | ☐ |
| 9 | Ajouter variables culturelles (Ramadan, Tabaski) | ☐ |
| 10 | **PROJET** : Script comparaison + rapport PDF | ☐ |

---

## 🔴 ÉTAPES SUIVANTES (résumé)

| Étape | Période | Contenu |
|-------|---------|---------|
| 5 | 22 sept - 31 oct | Intégration complète (IA + Dashboard + Reporting) |
| 6 | 1 nov - 31 déc | Tests, déploiement, validation avec la CDA |
| 7 | Jan - Mai 2027 | Rédaction du mémoire (6 chapitres, ~130 pages) |
| 8 | Juin 2027 | Préparation soutenance : slides + démo live |

---

## 📌 RÈGLES DE SUIVI

1. Chaque dimanche : faire le point
2. Chaque jour : Commit Git obligatoire
3. Chaque étape : valider les critères avant de passer à la suivante
4. Blocage > 2h : demander de l'aide
5. Documenter chaque décision technique

---

*4 modèles : Moyenne Mobile, Holt-Winters, SARIMA, Prophet*
