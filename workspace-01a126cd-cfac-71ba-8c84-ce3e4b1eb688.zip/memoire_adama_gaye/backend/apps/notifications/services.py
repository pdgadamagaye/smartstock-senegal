"""
SmartStock Sénégal - Module de Notifications (SMS/Email)
========================================================
Ce module gère l'envoi d'alertes automatiques via :
- SMS (simulation API Twilio ou opérateur local)
- Email (SMTP)

Auteur : Adama GAYE
"""

import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class SMSService:
    """
    Service d'envoi de SMS.
    
    En production : utiliser l'API Twilio ou un opérateur local (Orange, MTN).
    Pour le mémoire : simulation avec logs.
    """

    def __init__(self, api_key=None, api_secret=None, from_number=None):
        """
        Initialiser le service SMS.
        
        Args:
            api_key: Clé API du fournisseur SMS
            api_secret: Secret API
            from_number: Numéro d'expéditeur
        """
        self.api_key = api_key
        self.api_secret = api_secret
        self.from_number = from_number or "+221-XX-XXX-XX-XX"
        self.is_configured = all([api_key, api_secret])

    def send_sms(self, to_number, message):
        """
        Envoyer un SMS.
        
        Args:
            to_number: Numéro du destinataire (format: +221XXXXXXXXX)
            message: Contenu du SMS (max 160 caractères)
            
        Returns:
            Dict avec le statut de l'envoi
        """
        # Vérifier la longueur du message
        if len(message) > 160:
            message = message[:157] + "..."

        if self.is_configured:
            # En production : appel API Twilio
            # from twilio.rest import Client
            # client = Client(self.api_key, self.api_secret)
            # client.messages.create(body=message, from_=self.from_number, to=to_number)
            pass

        # SIMULATION (pour le mémoire)
        logger.info(f"📱 SMS envoyé à {to_number}: {message}")
        
        return {
            'success': True,
            'to': to_number,
            'message': message,
            'timestamp': datetime.now().isoformat(),
            'simulated': True  # Indique que c'est une simulation
        }

    def send_stock_alert(self, phone, product_name, current_stock, threshold):
        """
        Envoyer une alerte de stock critique par SMS.
        
        Args:
            phone: Numéro de téléphone du destinataire
            product_name: Nom du produit en rupture
            current_stock: Stock actuel
            threshold: Seuil minimum
        """
        message = (
            f"ALERTE STOCK SmartStock: {product_name} - "
            f"Stock actuel: {current_stock} (seuil: {threshold}). "
            f"Action requise: Commander immédiatement."
        )
        return self.send_sms(phone, message)

    def send_prediction_alert(self, phone, product_name, days_of_stock):
        """
        Envoyer une alerte basée sur les prédictions.
        """
        message = (
            f"SmartStock Prediction: {product_name} - "
            f"Rupture prévue dans {days_of_stock} jours. "
            f"Anticipez votre commande."
        )
        return self.send_sms(phone, message)


class EmailService:
    """
    Service d'envoi d'emails.
    
    Utilise SMTP (compatible Gmail, Outlook, ou serveur local).
    """

    def __init__(self, smtp_host=None, smtp_port=None,
                 username=None, password=None):
        """
        Initialiser le service email.
        
        Args:
            smtp_host: Serveur SMTP (ex: smtp.gmail.com)
            smtp_port: Port SMTP (587 pour TLS)
            username: Email de l'expéditeur
            password: Mot de passe ou App Password
        """
        self.smtp_host = smtp_host
        self.smtp_port = smtp_port or 587
        self.username = username
        self.password = password
        self.is_configured = all([smtp_host, username, password])

    def send_email(self, to_email, subject, body, html_body=None):
        """
        Envoyer un email.
        
        Args:
            to_email: Email du destinataire
            subject: Sujet de l'email
            body: Contenu texte
            html_body: Contenu HTML (optionnel)
            
        Returns:
            Dict avec le statut de l'envoi
        """
        if not self.is_configured:
            # Simulation
            logger.info(f"📧 EMAIL envoyé à {to_email}: {subject}")
            return {
                'success': True,
                'to': to_email,
                'subject': subject,
                'timestamp': datetime.now().isoformat(),
                'simulated': True
            }

        # Construction de l'email
        msg = MIMEMultipart('alternative')
        msg['From'] = self.username
        msg['To'] = to_email
        msg['Subject'] = subject

        # Corps texte
        msg.attach(MIMEText(body, 'plain', 'utf-8'))

        # Corps HTML
        if html_body:
            msg.attach(MIMEText(html_body, 'html', 'utf-8'))

        # Envoi
        try:
            with smtplib.SMTP(self.smtp_host, self.smtp_port) as server:
                server.starttls()
                server.login(self.username, self.password)
                server.send_message(msg)

            logger.info(f"📧 Email envoyé avec succès à {to_email}")
            return {
                'success': True,
                'to': to_email,
                'subject': subject,
                'timestamp': datetime.now().isoformat(),
                'simulated': False
            }
        except Exception as e:
            logger.error(f"Erreur envoi email: {str(e)}")
            return {
                'success': False,
                'error': str(e),
                'timestamp': datetime.now().isoformat()
            }

    def send_daily_report(self, to_email, report_data):
        """
        Envoyer un rapport journalier des ventes et stocks.
        
        Args:
            to_email: Email du destinataire
            report_data: Dict avec les données du rapport
        """
        subject = f"📊 Rapport SmartStock - {datetime.now().strftime('%d/%m/%Y')}"

        body = self._generate_report_text(report_data)
        html_body = self._generate_report_html(report_data)

        return self.send_email(to_email, subject, body, html_body)

    def send_stock_alert_email(self, to_email, alerts):
        """
        Envoyer un email avec les alertes de stock.
        """
        subject = f"⚠️ Alertes de Stock - SmartStock - {datetime.now().strftime('%d/%m/%Y')}"

        body = "ALERTES DE STOCK CRITIQUES\n\n"
        for alert in alerts:
            body += f"- [{alert['level']}] {alert['message']}\n"

        html_body = self._generate_alert_html(alerts)

        return self.send_email(to_email, subject, body, html_body)

    def _generate_report_text(self, data):
        """Générer le rapport en texte brut"""
        return (
            f"RAPPORT JOURNALIER SMARTSTOCK\n"
            f"{'='*40}\n\n"
            f"Date: {datetime.now().strftime('%d/%m/%Y')}\n\n"
            f"CHIFFRES DU JOUR:\n"
            f"- Chiffre d'affaires: {data.get('revenue_today', 0):,} FCFA\n"
            f"- Nombre de ventes: {data.get('sales_count', 0)}\n"
            f"- Produits en stock faible: {data.get('low_stock', 0)}\n\n"
            f"TOP 3 PRODUITS:\n"
            f"{self._format_top_products(data.get('top_products', []))}\n\n"
            f"--\nSmartStock Sénégal"
        )

    def _generate_report_html(self, data):
        """Générer le rapport en HTML"""
        top_products_html = ""
        for i, p in enumerate(data.get('top_products', [])[:3], 1):
            top_products_html += f"<li>{p.get('name', 'N/A')} - {p.get('revenue', 0):,} FCFA</li>"

        return f"""
        <html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #1a73e8;">📊 Rapport SmartStock</h2>
            <p>Date : {datetime.now().strftime('%d/%m/%Y')}</p>
            
            <h3>Chiffres du jour</h3>
            <table style="border-collapse: collapse; width: 100%;">
                <tr style="background: #f5f5f5;">
                    <td style="padding: 10px; border: 1px solid #ddd;"><b>Chiffre d'affaires</b></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        {data.get('revenue_today', 0):,} FCFA
                    </td>
                </tr>
                <tr>
                    <td style="padding: 10px; border: 1px solid #ddd;"><b>Nombre de ventes</b></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        {data.get('sales_count', 0)}
                    </td>
                </tr>
                <tr style="background: #f5f5f5;">
                    <td style="padding: 10px; border: 1px solid #ddd;"><b>Alertes stock</b></td>
                    <td style="padding: 10px; border: 1px solid #ddd;">
                        {data.get('low_stock', 0)} produit(s)
                    </td>
                </tr>
            </table>

            <h3>Top 3 Produits</h3>
            <ol>{top_products_html}</ol>

            <hr>
            <p style="color: #666; font-size: 12px;">
                SmartStock Sénégal - Gestion Commerciale Intelligente
            </p>
        </body>
        </html>
        """

    def _generate_alert_html(self, alerts):
        """Générer le HTML pour les alertes"""
        alert_rows = ""
        colors = {
            'CRITICAL': '#dc3545',
            'HIGH': '#fd7e14',
            'MEDIUM': '#ffc107',
            'LOW': '#28a745'
        }

        for alert in alerts:
            color = colors.get(alert['level'], '#6c757d')
            alert_rows += f"""
            <tr>
                <td style="padding: 10px; border: 1px solid #ddd;">
                    <span style="color: {color}; font-weight: bold;">
                        {alert['level']}
                    </span>
                </td>
                <td style="padding: 10px; border: 1px solid #ddd;">
                    {alert['message']}
                </td>
            </tr>
            """

        return f"""
        <html>
        <body style="font-family: Arial, sans-serif; padding: 20px;">
            <h2 style="color: #dc3545;">⚠️ Alertes de Stock</h2>
            <p>Date : {datetime.now().strftime('%d/%m/%Y %H:%M')}</p>
            
            <table style="border-collapse: collapse; width: 100%;">
                <tr style="background: #f5f5f5;">
                    <th style="padding: 10px; border: 1px solid #ddd;">Niveau</th>
                    <th style="padding: 10px; border: 1px solid #ddd;">Message</th>
                </tr>
                {alert_rows}
            </table>

            <hr>
            <p style="color: #666; font-size: 12px;">
                SmartStock Sénégal - Action requise
            </p>
        </body>
        </html>
        """

    def _format_top_products(self, products):
        """Formater les top produits en texte"""
        text = ""
        for i, p in enumerate(products[:3], 1):
            text += f"{i}. {p.get('name', 'N/A')} - {p.get('revenue', 0):,} FCFA\n"
        return text


# ==================== SERVICE COMBINÉ ====================

class NotificationService:
    """
    Service unifié de notifications.
    Combine SMS et Email pour envoyer des alertes.
    """

    def __init__(self, sms_service=None, email_service=None):
        self.sms = sms_service or SMSService()
        self.email = email_service or EmailService()

    def send_alert(self, alert, recipients):
        """
        Envoyer une alerte par tous les canaux configurés.
        
        Args:
            alert: Dict avec les informations de l'alerte
            recipients: Dict avec 'phone' et/ou 'email'
        """
        results = {'sms': None, 'email': None}

        # SMS
        if recipients.get('phone') and alert['level'] in ['CRITICAL', 'HIGH']:
            results['sms'] = self.sms.send_sms(
                recipients['phone'],
                alert['message']
            )

        # Email
        if recipients.get('email'):
            results['email'] = self.email.send_stock_alert_email(
                recipients['email'],
                [alert]
            )

        return results

    def send_daily_summary(self, report_data, recipients):
        """Envoyer le rapport journalier"""
        results = {'email': None}

        if recipients.get('email'):
            results['email'] = self.email.send_daily_report(
                recipients['email'],
                report_data
            )

        return results
