"""
SmartStock — Module d'Automatisation du Reporting
===================================================
Génération automatique de rapports commerciaux PDF et Excel
pour les PME sénégalaises de distribution alimentaire.

Auteur : Adama GAYE — UCAO Dakar 2026-2027
"""

import os
import pandas as pd
from datetime import datetime, timedelta
from io import BytesIO

# ======================================================================
# MODULE REPORTLAB — GÉNÉRATION PDF
# ======================================================================

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import cm, mm
from reportlab.platypus import (
    SimpleDocTemplate, Table, TableStyle, Paragraph,
    Spacer, Image, PageBreak, HRFlowable
)
from reportlab.pdfgen import canvas


class PDFReportGenerator:
    """
    Génère des rapports commerciaux au format PDF.
    
    Types de rapports :
    - Rapport journalier (CA du jour, top produits, alertes)
    - Rapport hebdomadaire (tendance de la semaine)
    - Rapport mensuel (bilan complet + prédictions)
    """

    def __init__(self, company_name="CDA", output_dir="reports/"):
        self.company_name = company_name
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

        # Styles
        self.styles = getSampleStyleSheet()
        self.styles.add(ParagraphStyle(
            'Title_Custom',
            parent=self.styles['Title'],
            fontSize=18,
            textColor=colors.HexColor('#1a73e8'),
            spaceAfter=20
        ))
        self.styles.add(ParagraphStyle(
            'Heading_Custom',
            parent=self.styles['Heading2'],
            fontSize=14,
            textColor=colors.HexColor('#333333'),
            spaceAfter=10
        ))

    def generate_daily_report(self, data, date=None):
        """
        Générer un rapport journalier en PDF.
        
        Args:
            data: dict avec les données du rapport
                - revenue: chiffre d'affaires du jour
                - sales_count: nombre de ventes
                - top_products: liste des top produits
                - alerts: liste des alertes
                - comparison: comparaison avec la veille
                
        Returns:
            Chemin du fichier PDF généré
        """
        if date is None:
            date = datetime.now()

        filename = f"{self.output_dir}/rapport_journalier_{date.strftime('%Y%m%d')}.pdf"

        doc = SimpleDocTemplate(
            filename,
            pagesize=A4,
            rightMargin=2*cm,
            leftMargin=2*cm,
            topMargin=2*cm,
            bottomMargin=2*cm
        )

        elements = []

        # En-tête
        elements.append(Paragraph(
            f"📊 Rapport Journalier — {self.company_name}",
            self.styles['Title_Custom']
        ))
        elements.append(Paragraph(
            f"Date : {date.strftime('%d %B %Y')}",
            self.styles['Normal']
        ))
        elements.append(Spacer(1, 0.5*cm))
        elements.append(HRFlowable(
            width="100%", thickness=2, color=colors.HexColor('#1a73e8')
        ))
        elements.append(Spacer(1, 0.5*cm))

        # Chiffres clés
        elements.append(Paragraph("Chiffres Clés", self.styles['Heading_Custom']))

        kpi_data = [
            ['Indicateur', 'Valeur', 'Variation'],
            ['Chiffre d\'affaires', f"{data.get('revenue', 0):,.0f} FCFA",
             data.get('revenue_change', '+0%')],
            ['Nombre de ventes', str(data.get('sales_count', 0)),
             data.get('sales_change', '+0')],
            ['Panier moyen', f"{data.get('average_basket', 0):,.0f} FCFA",
             data.get('basket_change', '+0%')],
            ['Clients actifs', str(data.get('active_clients', 0)),
             data.get('clients_change', '+0')],
        ]

        kpi_table = Table(kpi_data, colWidths=[5*cm, 4*cm, 3*cm])
        kpi_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a73e8')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 10),
            ('BACKGROUND', (0, 1), (-1, -1), colors.HexColor('#f5f5f5')),
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
        ]))
        elements.append(kpi_table)
        elements.append(Spacer(1, 0.8*cm))

        # Top produits
        elements.append(Paragraph("Top 5 Produits", self.styles['Heading_Custom']))

        top_products = data.get('top_products', [])
        if top_products:
            product_data = [['#', 'Produit', 'Quantité', 'Revenu (FCFA)']]
            for i, p in enumerate(top_products[:5], 1):
                product_data.append([
                    str(i),
                    p.get('name', 'N/A'),
                    str(p.get('quantity', 0)),
                    f"{p.get('revenue', 0):,.0f}"
                ])

            product_table = Table(product_data, colWidths=[1*cm, 5*cm, 3*cm, 3.5*cm])
            product_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#34a853')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#f5f5f5')]),
            ]))
            elements.append(product_table)
        else:
            elements.append(Paragraph("Aucune donnée disponible", self.styles['Normal']))

        elements.append(Spacer(1, 0.8*cm))

        # Alertes
        elements.append(Paragraph("Alertes de Stock", self.styles['Heading_Custom']))

        alerts = data.get('alerts', [])
        if alerts:
            alert_data = [['Niveau', 'Produit', 'Stock', 'Action']]
            for a in alerts:
                alert_data.append([
                    a.get('level', 'N/A'),
                    a.get('product', 'N/A'),
                    str(a.get('stock', 0)),
                    a.get('action', 'N/A')
                ])

            alert_table = Table(alert_data, colWidths=[2.5*cm, 5*cm, 2.5*cm, 3*cm])
            alert_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#ea4335')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ]))
            elements.append(alert_table)
        else:
            elements.append(Paragraph("✅ Aucune alerte", self.styles['Normal']))

        elements.append(Spacer(1, 1*cm))

        # Prédictions
        elements.append(Paragraph("Prédictions IA (7 prochains jours)", self.styles['Heading_Custom']))

        predictions = data.get('predictions', [])
        if predictions:
            pred_data = [['Date', 'Ventes prévues (FCFA)', 'Intervalle de confiance']]
            for p in predictions[:7]:
                pred_data.append([
                    p.get('date', 'N/A'),
                    f"{p.get('yhat', 0):,.0f}",
                    f"[{p.get('lower', 0):,.0f} - {p.get('upper', 0):,.0f}]"
                ])

            pred_table = Table(pred_data, colWidths=[4*cm, 4*cm, 5*cm])
            pred_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#fbbc04')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.black),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
                ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#fff8e1')]),
            ]))
            elements.append(pred_table)

        # Pied de page
        elements.append(Spacer(1, 2*cm))
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
        elements.append(Paragraph(
            f"SmartStock — Système d'Aide à la Décision — {self.company_name} — "
            f"Généré le {datetime.now().strftime('%d/%m/%Y à %H:%M')}",
            ParagraphStyle('Footer', fontSize=8, textColor=colors.grey)
        ))

        doc.build(elements)
        return filename

    def generate_monthly_report(self, data, month=None, year=None):
        """
        Générer un rapport mensuel complet en PDF.
        
        Inclut : bilan du mois, comparaisons, prédictions, recommandations.
        """
        if month is None:
            month = datetime.now().month
        if year is None:
            year = datetime.now().year

        filename = f"{self.output_dir}/rapport_mensuel_{year}{month:02d}.pdf"

        doc = SimpleDocTemplate(filename, pagesize=A4,
                                rightMargin=2*cm, leftMargin=2*cm,
                                topMargin=2*cm, bottomMargin=2*cm)
        elements = []

        # Page de couverture
        elements.append(Spacer(1, 5*cm))
        elements.append(Paragraph(
            f"RAPPORT MENSUEL",
            self.styles['Title_Custom']
        ))
        elements.append(Paragraph(
            f"{self.company_name}",
            ParagraphStyle('Company', fontSize=24, alignment=1,
                           textColor=colors.HexColor('#333333'))
        ))
        elements.append(Spacer(1, 1*cm))
        month_names = [
            'Janvier', 'Février', 'Mars', 'Avril', 'Mai', 'Juin',
            'Juillet', 'Août', 'Septembre', 'Octobre', 'Novembre', 'Décembre'
        ]
        elements.append(Paragraph(
            f"{month_names[month-1]} {year}",
            ParagraphStyle('Month', fontSize=18, alignment=1,
                           textColor=colors.HexColor('#1a73e8'))
        ))
        elements.append(Spacer(1, 3*cm))
        elements.append(Paragraph(
            "Système d'Aide à la Décision — SmartStock",
            ParagraphStyle('Subtitle', fontSize=12, alignment=1,
                           textColor=colors.grey)
        ))
        elements.append(PageBreak())

        # Résumé exécutif
        elements.append(Paragraph("Résumé Exécutif", self.styles['Title_Custom']))
        elements.append(Spacer(1, 0.5*cm))

        summary = data.get('summary', {})
        elements.append(Paragraph(
            f"Chiffre d'affaires mensuel : <b>{summary.get('total_revenue', 0):,.0f} FCFA</b>",
            self.styles['Normal']
        ))
        elements.append(Paragraph(
            f"Nombre total de ventes : <b>{summary.get('total_sales', 0)}</b>",
            self.styles['Normal']
        ))
        elements.append(Paragraph(
            f"Variation vs mois précédent : <b>{summary.get('variation', '+0%')}</b>",
            self.styles['Normal']
        ))
        elements.append(Paragraph(
            f"Alertes générées : <b>{summary.get('alerts_count', 0)}</b>",
            self.styles['Normal']
        ))
        elements.append(Spacer(1, 1*cm))

        # Analyse par site (multi-sites CDA)
        elements.append(Paragraph("Analyse par Site", self.styles['Heading_Custom']))
        sites = data.get('sites', [])
        if sites:
            site_data = [['Site', 'CA (FCFA)', 'Ventes', 'Top Produit']]
            for s in sites:
                site_data.append([
                    s.get('name', 'N/A'),
                    f"{s.get('revenue', 0):,.0f}",
                    str(s.get('sales', 0)),
                    s.get('top_product', 'N/A')
                ])
            site_table = Table(site_data, colWidths=[3.5*cm, 3.5*cm, 2.5*cm, 3.5*cm])
            site_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1a73e8')),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
                ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ]))
            elements.append(site_table)

        elements.append(Spacer(1, 1*cm))

        # Recommandations IA
        elements.append(Paragraph("Recommandations du Système IA", self.styles['Heading_Custom']))
        recommendations = data.get('recommendations', [])
        for i, rec in enumerate(recommendations, 1):
            elements.append(Paragraph(f"{i}. {rec}", self.styles['Normal']))
            elements.append(Spacer(1, 0.2*cm))

        # Pied de page
        elements.append(Spacer(1, 3*cm))
        elements.append(HRFlowable(width="100%", thickness=1, color=colors.grey))
        elements.append(Paragraph(
            f"Rapport généré automatiquement par SmartStock — {datetime.now().strftime('%d/%m/%Y')}",
            ParagraphStyle('Footer', fontSize=8, textColor=colors.grey)
        ))

        doc.build(elements)
        return filename


# ======================================================================
# MODULE PANDAS — GÉNÉRATION EXCEL
# ======================================================================

class ExcelReportGenerator:
    """
    Génère des rapports commerciaux au format Excel (.xlsx).
    
    Utilise Pandas + openpyxl pour des rapports multi-feuilles.
    """

    def __init__(self, output_dir="reports/"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def generate_daily_excel(self, data, date=None):
        """
        Rapport journalier Excel avec plusieurs feuilles :
        - Résumé (KPIs)
        - Détail des ventes
        - Top produits
        - Alertes
        - Prédictions
        """
        if date is None:
            date = datetime.now()

        filename = f"{self.output_dir}/rapport_journalier_{date.strftime('%Y%m%d')}.xlsx"

        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            # Feuille 1 : Résumé KPI
            summary_data = {
                'Indicateur': [
                    'Chiffre d\'affaires', 'Nombre de ventes',
                    'Panier moyen', 'Clients actifs',
                    'Produits en stock faible', 'Alertes'
                ],
                'Valeur': [
                    f"{data.get('revenue', 0):,.0f} FCFA",
                    data.get('sales_count', 0),
                    f"{data.get('average_basket', 0):,.0f} FCFA",
                    data.get('active_clients', 0),
                    data.get('low_stock_count', 0),
                    len(data.get('alerts', []))
                ],
                'Variation': [
                    data.get('revenue_change', 'N/A'),
                    data.get('sales_change', 'N/A'),
                    data.get('basket_change', 'N/A'),
                    data.get('clients_change', 'N/A'),
                    '', ''
                ]
            }
            df_summary = pd.DataFrame(summary_data)
            df_summary.to_excel(writer, sheet_name='Résumé', index=False)

            # Feuille 2 : Détail des ventes
            sales = data.get('sales_detail', [])
            if sales:
                df_sales = pd.DataFrame(sales)
                df_sales.to_excel(writer, sheet_name='Ventes', index=False)

            # Feuille 3 : Top produits
            top_products = data.get('top_products', [])
            if top_products:
                df_top = pd.DataFrame(top_products)
                df_top.to_excel(writer, sheet_name='Top Produits', index=False)

            # Feuille 4 : Alertes
            alerts = data.get('alerts', [])
            if alerts:
                df_alerts = pd.DataFrame(alerts)
                df_alerts.to_excel(writer, sheet_name='Alertes', index=False)

            # Feuille 5 : Prédictions
            predictions = data.get('predictions', [])
            if predictions:
                df_pred = pd.DataFrame(predictions)
                df_pred.to_excel(writer, sheet_name='Prédictions IA', index=False)

        return filename

    def generate_monthly_excel(self, data, month=None, year=None):
        """
        Rapport mensuel Excel complet.
        """
        if month is None:
            month = datetime.now().month
        if year is None:
            year = datetime.now().year

        filename = f"{self.output_dir}/rapport_mensuel_{year}{month:02d}.xlsx"

        with pd.ExcelWriter(filename, engine='openpyxl') as writer:
            # Feuille 1 : Bilan mensuel
            summary = data.get('summary', {})
            bilan_data = {
                'Indicateur': [
                    'Chiffre d\'affaires total', 'Nombre de ventes',
                    'Panier moyen', 'Nombre de clients',
                    'Variation CA vs mois précédent',
                    'Produits les plus vendus',
                    'Jour avec le plus de ventes'
                ],
                'Valeur': [
                    f"{summary.get('total_revenue', 0):,.0f} FCFA",
                    summary.get('total_sales', 0),
                    f"{summary.get('avg_basket', 0):,.0f} FCFA",
                    summary.get('total_clients', 0),
                    summary.get('variation', 'N/A'),
                    summary.get('top_product', 'N/A'),
                    summary.get('best_day', 'N/A')
                ]
            }
            df_bilan = pd.DataFrame(bilan_data)
            df_bilan.to_excel(writer, sheet_name='Bilan', index=False)

            # Feuille 2 : Ventes par jour
            daily = data.get('daily_sales', [])
            if daily:
                df_daily = pd.DataFrame(daily)
                df_daily.to_excel(writer, sheet_name='Ventes par jour', index=False)

            # Feuille 3 : Analyse par produit
            by_product = data.get('by_product', [])
            if by_product:
                df_product = pd.DataFrame(by_product)
                df_product.to_excel(writer, sheet_name='Par Produit', index=False)

            # Feuille 4 : Analyse par site
            by_site = data.get('by_site', [])
            if by_site:
                df_site = pd.DataFrame(by_site)
                df_site.to_excel(writer, sheet_name='Par Site', index=False)

            # Feuille 5 : Prédictions
            predictions = data.get('predictions', [])
            if predictions:
                df_pred = pd.DataFrame(predictions)
                df_pred.to_excel(writer, sheet_name='Prédictions', index=False)

        return filename


# ======================================================================
# SERVICE COMBINÉ : PDF + EXCEL + EMAIL
# ======================================================================

class ReportingService:
    """
    Service unifié de reporting automatisé.
    
    Combine :
    - Génération PDF (ReportLab)
    - Génération Excel (Pandas + openpyxl)
    - Planification automatique
    - Envoi par email
    """

    def __init__(self, company_name="CDA", output_dir="reports/"):
        self.pdf_gen = PDFReportGenerator(company_name, output_dir)
        self.excel_gen = ExcelReportGenerator(output_dir)
        self.company_name = company_name

    def generate_daily_reports(self, data, date=None, formats=['pdf', 'excel']):
        """
        Générer les rapports journaliers dans les formats demandés.
        
        Returns:
            Liste des chemins des fichiers générés
        """
        files = []

        if 'pdf' in formats:
            pdf_path = self.pdf_gen.generate_daily_report(data, date)
            files.append(pdf_path)

        if 'excel' in formats:
            excel_path = self.excel_gen.generate_daily_excel(data, date)
            files.append(excel_path)

        return files

    def generate_monthly_reports(self, data, month=None, year=None,
                                  formats=['pdf', 'excel']):
        """
        Générer les rapports mensuels dans les formats demandés.
        """
        files = []

        if 'pdf' in formats:
            pdf_path = self.pdf_gen.generate_monthly_report(data, month, year)
            files.append(pdf_path)

        if 'excel' in formats:
            excel_path = self.excel_gen.generate_monthly_excel(data, month, year)
            files.append(excel_path)

        return files

    def generate_all(self, daily_data=None, monthly_data=None):
        """
        Générer tous les rapports (journalier + mensuel).
        """
        files = []

        if daily_data:
            files.extend(self.generate_daily_reports(daily_data))

        if monthly_data:
            files.extend(self.generate_monthly_reports(monthly_data))

        return files


# ======================================================================
# TEST — Génération d'un rapport de démonstration
# ======================================================================

if __name__ == "__main__":
    print("=" * 60)
    print("SmartStock — Module de Reporting Automatisé")
    print("=" * 60)

    # Données de démonstration (simulation CDA)
    daily_data = {
        'revenue': 2500000,
        'revenue_change': '+12%',
        'sales_count': 45,
        'sales_change': '+5',
        'average_basket': 55556,
        'basket_change': '+8%',
        'active_clients': 32,
        'clients_change': '+3',
        'low_stock_count': 4,
        'top_products': [
            {'name': 'Riz parfumé 5kg', 'quantity': 120, 'revenue': 540000},
            {'name': 'Huile vegetale 1L', 'quantity': 85, 'revenue': 340000},
            {'name': 'Sucre 1kg', 'quantity': 200, 'revenue': 300000},
            {'name': 'Tomate concentrée', 'quantity': 150, 'revenue': 225000},
            {'name': 'Lait en poudre 400g', 'quantity': 60, 'revenue': 180000},
        ],
        'alerts': [
            {'level': 'CRITIQUE', 'product': 'Huile 5L', 'stock': 2,
             'action': 'Commander immédiatement'},
            {'level': 'FAIBLE', 'product': 'Farine de mil', 'stock': 8,
             'action': 'Planifier commande'},
        ],
        'predictions': [
            {'date': (datetime.now() + timedelta(days=i)).strftime('%d/%m'),
             'yhat': 2500000 + (i * 50000), 'lower': 2200000 + (i * 40000),
             'upper': 2800000 + (i * 60000)}
            for i in range(1, 8)
        ],
    }

    # Générer les rapports
    service = ReportingService(company_name="CDA")

    print("\n📄 Génération du rapport journalier PDF...")
    pdf_path = service.pdf_gen.generate_daily_report(daily_data)
    print(f"   → {pdf_path}")

    print("\n📊 Génération du rapport journalier Excel...")
    excel_path = service.excel_gen.generate_daily_excel(daily_data)
    print(f"   → {excel_path}")

    # Données mensuelles
    monthly_data = {
        'summary': {
            'total_revenue': 75000000,
            'total_sales': 1350,
            'avg_basket': 55556,
            'total_clients': 85,
            'variation': '+15%',
            'top_product': 'Riz parfumé 5kg',
            'best_day': '25 du mois (fin de salaire)',
        },
        'sites': [
            {'name': 'Plateau (Siège)', 'revenue': 45000000,
             'sales': 810, 'top_product': 'Riz parfumé'},
            {'name': 'Sébikotane', 'revenue': 30000000,
             'sales': 540, 'top_product': 'Huile végétale'},
        ],
        'recommendations': [
            "Augmenter le stock de riz parfumé de 20% pour le mois prochain (tendance haussière).",
            "Prévoir une promotion sur les conserves (rotation lente détectée).",
            "Le site de Sébikotane devrait augmenter ses commandes d'huile de 15%.",
            "Attention : rupture prédite de lait en poudre dans 5 jours.",
        ],
    }

    print("\n📄 Génération du rapport mensuel PDF...")
    pdf_monthly = service.pdf_gen.generate_monthly_report(monthly_data)
    print(f"   → {pdf_monthly}")

    print("\n📊 Génération du rapport mensuel Excel...")
    excel_monthly = service.excel_gen.generate_monthly_excel(monthly_data)
    print(f"   → {excel_monthly}")

    print("\n✅ Tous les rapports générés avec succès !")
    print("=" * 60)
