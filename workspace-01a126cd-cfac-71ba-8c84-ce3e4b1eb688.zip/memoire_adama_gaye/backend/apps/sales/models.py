"""
SmartStock Sénégal - Backend Django
Modèle de données : Sales (Ventes)
"""
from django.db import models
from django.core.validators import MinValueValidator
from apps.products.models import Product


class Client(models.Model):
    """Client de la PME"""
    CLIENT_TYPES = [
        ('particulier', 'Particulier'),
        ('grossiste', 'Grossiste'),
        ('detaillant', 'Détaillant'),
        ('entreprise', 'Entreprise'),
    ]

    name = models.CharField(max_length=200, verbose_name="Nom complet")
    phone = models.CharField(max_length=20, blank=True, verbose_name="Téléphone")
    email = models.EmailField(blank=True, verbose_name="Email")
    address = models.TextField(blank=True, verbose_name="Adresse")
    city = models.CharField(max_length=100, default="Dakar", verbose_name="Ville")
    client_type = models.CharField(
        max_length=20, choices=CLIENT_TYPES, default='particulier',
        verbose_name="Type de client"
    )
    is_active = models.BooleanField(default=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Client"
        verbose_name_plural = "Clients"
        ordering = ['name']

    def __str__(self):
        return self.name

    @property
    def total_purchases(self):
        """Montant total des achats du client"""
        return self.sales.aggregate(
            total=models.Sum('total_amount')
        )['total'] or 0

    @property
    def number_of_purchases(self):
        """Nombre total d'achats"""
        return self.sales.count()


class Sale(models.Model):
    """Enregistrement d'une vente"""
    PAYMENT_METHODS = [
        ('cash', 'Espèces'),
        ('wave', 'Wave'),
        ('orange_money', 'Orange Money'),
        ('mtn_money', 'MTN Money'),
        ('check', 'Chèque'),
        ('credit', 'Crédit'),
        ('bank_transfer', 'Virement bancaire'),
    ]

    STATUS_CHOICES = [
        ('pending', 'En attente'),
        ('completed', 'Complétée'),
        ('cancelled', 'Annulée'),
        ('refunded', 'Remboursée'),
    ]

    reference = models.CharField(max_length=50, unique=True, verbose_name="Référence")
    client = models.ForeignKey(
        Client, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='sales', verbose_name="Client"
    )
    sale_date = models.DateTimeField(verbose_name="Date de vente")
    payment_method = models.CharField(
        max_length=20, choices=PAYMENT_METHODS, default='cash',
        verbose_name="Mode de paiement"
    )
    status = models.CharField(
        max_length=20, choices=STATUS_CHOICES, default='completed',
        verbose_name="Statut"
    )
    discount = models.DecimalField(
        max_digits=10, decimal_places=2, default=0,
        verbose_name="Remise (FCFA)"
    )
    total_amount = models.DecimalField(
        max_digits=12, decimal_places=2, default=0,
        verbose_name="Montant total (FCFA)"
    )
    notes = models.TextField(blank=True, verbose_name="Notes")
    created_by = models.ForeignKey(
        'auth.User', on_delete=models.SET_NULL, null=True,
        verbose_name="Enregistré par"
    )
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Vente"
        verbose_name_plural = "Ventes"
        ordering = ['-sale_date']

    def __str__(self):
        return f"Vente #{self.reference} - {self.total_amount} FCFA"

    def calculate_total(self):
        """Recalcule le total de la vente"""
        items_total = sum(
            item.subtotal for item in self.items.all()
        )
        self.total_amount = items_total - self.discount
        self.save()
        return self.total_amount


class SaleItem(models.Model):
    """Ligne d'article dans une vente"""
    sale = models.ForeignKey(
        Sale, on_delete=models.CASCADE, related_name='items',
        verbose_name="Vente"
    )
    product = models.ForeignKey(
        Product, on_delete=models.PROTECT,
        verbose_name="Produit"
    )
    quantity = models.PositiveIntegerField(
        validators=[MinValueValidator(1)],
        verbose_name="Quantité"
    )
    unit_price = models.DecimalField(
        max_digits=10, decimal_places=2,
        verbose_name="Prix unitaire (FCFA)"
    )
    discount = models.DecimalField(
        max_digits=10, decimal_places=2, default=0,
        verbose_name="Remise ligne (FCFA)"
    )

    class Meta:
        verbose_name = "Ligne de vente"
        verbose_name_plural = "Lignes de vente"

    def __str__(self):
        return f"{self.product.name} x{self.quantity}"

    @property
    def subtotal(self):
        """Sous-total de la ligne"""
        return (self.quantity * self.unit_price) - self.discount

    def save(self, *args, **kwargs):
        """Automatiquement mettre à jour le prix unitaire depuis le produit"""
        if not self.unit_price:
            self.unit_price = self.product.selling_price
        super().save(*args, **kwargs)
