"""
SmartStock Sénégal - Backend Django
Vues API pour les ventes et le tableau de bord
"""
from rest_framework import viewsets, status
from rest_framework.decorators import action, api_view
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Sum, Count, Avg, F, Q
from datetime import timedelta, date

from apps.sales.models import Sale, SaleItem, Client
from apps.sales.serializers import (
    SaleSerializer, SaleCreateSerializer, ClientSerializer
)
from apps.products.models import Product


class ClientViewSet(viewsets.ModelViewSet):
    """API endpoint pour les clients"""
    queryset = Client.objects.all()
    serializer_class = ClientSerializer


class SaleViewSet(viewsets.ModelViewSet):
    """API endpoint pour les ventes"""
    queryset = Sale.objects.select_related('client').prefetch_related('items').all()

    def get_serializer_class(self):
        if self.action == 'create':
            return SaleCreateSerializer
        return SaleSerializer

    def get_queryset(self):
        """Filtrer par date, client, statut"""
        queryset = super().get_queryset()
        start_date = self.request.query_params.get('start_date')
        end_date = self.request.query_params.get('end_date')
        client_id = self.request.query_params.get('client')
        status_filter = self.request.query_params.get('status')

        if start_date:
            queryset = queryset.filter(sale_date__date__gte=start_date)
        if end_date:
            queryset = queryset.filter(sale_date__date__lte=end_date)
        if client_id:
            queryset = queryset.filter(client_id=client_id)
        if status_filter:
            queryset = queryset.filter(status=status_filter)
        return queryset

    @action(detail=False, methods=['get'])
    def daily_summary(self, request):
        """Résumé des ventes par jour (pour les graphiques)"""
        days = int(request.query_params.get('days', 30))
        start_date = timezone.now() - timedelta(days=days)

        daily_sales = (
            Sale.objects
            .filter(sale_date__gte=start_date, status='completed')
            .values('sale_date__date')
            .annotate(
                total_revenue=Sum('total_amount'),
                count=Count('id')
            )
            .order_by('sale_date__date')
        )

        return Response(daily_sales)

    @action(detail=False, methods=['get'])
    def top_products(self, request):
        """Top 10 des produits les plus vendus"""
        days = int(request.query_params.get('days', 30))
        start_date = timezone.now() - timedelta(days=days)

        top = (
            SaleItem.objects
            .filter(sale__sale_date__gte=start_date, sale__status='completed')
            .values('product__name', 'product__id')
            .annotate(
                total_quantity=Sum('quantity'),
                total_revenue=Sum(F('quantity') * F('unit_price'))
            )
            .order_by('-total_revenue')[:10]
        )

        return Response(top)

    @action(detail=False, methods=['get'])
    def payment_methods_stats(self, request):
        """Statistiques par mode de paiement"""
        days = int(request.query_params.get('days', 30))
        start_date = timezone.now() - timedelta(days=days)

        stats = (
            Sale.objects
            .filter(sale_date__gte=start_date, status='completed')
            .values('payment_method')
            .annotate(
                total=Sum('total_amount'),
                count=Count('id')
            )
            .order_by('-total')
        )

        return Response(stats)


# ==================== DASHBOARD ====================

@api_view(['GET'])
def dashboard_view(request):
    """Vue principale du tableau de bord - KPIs"""
    today = timezone.now().date()
    thirty_days_ago = timezone.now() - timedelta(days=30)

    # KPIs principaux
    total_revenue = (
        Sale.objects
        .filter(status='completed')
        .aggregate(total=Sum('total_amount'))['total'] or 0
    )

    revenue_today = (
        Sale.objects
        .filter(sale_date__date=today, status='completed')
        .aggregate(total=Sum('total_amount'))['total'] or 0
    )

    revenue_30days = (
        Sale.objects
        .filter(sale_date__gte=thirty_days_ago, status='completed')
        .aggregate(total=Sum('total_amount'))['total'] or 0
    )

    total_sales = Sale.objects.filter(status='completed').count()
    total_products = Product.objects.filter(is_active=True).count()
    total_clients = Client.objects.filter(is_active=True).count()
    low_stock_count = Product.objects.filter(
        is_active=True
    ).count()  # Simplified - en prod, annoter avec stock actuel

    # Ventes récentes
    recent_sales = Sale.objects.select_related('client').filter(
        status='completed'
    ).order_by('-sale_date')[:5]

    return Response({
        'total_revenue': total_revenue,
        'revenue_today': revenue_today,
        'revenue_30days': revenue_30days,
        'total_sales': total_sales,
        'total_products': total_products,
        'total_clients': total_clients,
        'low_stock_count': low_stock_count,
        'recent_sales': SaleSerializer(recent_sales, many=True).data,
    })
