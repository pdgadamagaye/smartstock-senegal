"""
SmartStock Sénégal - Backend Django
Vues API pour les produits
"""
from rest_framework import viewsets, status, filters
from rest_framework.decorators import action
from rest_framework.response import Response
from django.utils import timezone
from django.db.models import Sum, Count, Q, F
from datetime import timedelta

from apps.products.models import Product, Category, StockMovement
from apps.products.serializers import (
    ProductSerializer, CategorySerializer, StockMovementSerializer
)


class CategoryViewSet(viewsets.ModelViewSet):
    """API endpoint pour les catégories de produits"""
    queryset = Category.objects.all()
    serializer_class = CategorySerializer
    filter_backends = [filters.SearchFilter]
    search_fields = ['name']


class ProductViewSet(viewsets.ModelViewSet):
    """API endpoint pour les produits"""
    queryset = Product.objects.select_related('category').all()
    serializer_class = ProductSerializer
    filter_backends = [filters.SearchFilter, filters.OrderingFilter]
    search_fields = ['name', 'reference']
    ordering_fields = ['name', 'selling_price', 'created_at']

    def get_queryset(self):
        """Filtrer par catégorie ou statut de stock"""
        queryset = super().get_queryset()
        category = self.request.query_params.get('category')
        low_stock = self.request.query_params.get('low_stock')

        if category:
            queryset = queryset.filter(category__id=category)
        if low_stock == 'true':
            # Produits avec stock <= seuil minimum
            queryset = queryset.annotate(
                current_stock_val=Sum(
                    'stock_movements__quantity',
                    filter=Q(stock_movements__movement_type='IN')
                ) - Sum(
                    'stock_movements__quantity',
                    filter=Q(stock_movements__movement_type='OUT')
                )
            )
            queryset = queryset.filter(
                current_stock_val__lte=F('min_stock_threshold')
            )
        return queryset

    @action(detail=True, methods=['post'])
    def add_stock(self, request, pk=None):
        """Ajouter du stock à un produit"""
        product = self.get_object()
        quantity = request.data.get('quantity')
        reason = request.data.get('reason', 'Approvisionnement')

        if not quantity or int(quantity) <= 0:
            return Response(
                {'error': 'Quantité invalide'},
                status=status.HTTP_400_BAD_REQUEST
            )

        movement = StockMovement.objects.create(
            product=product,
            movement_type='IN',
            quantity=int(quantity),
            reason=reason,
            performed_by=request.user
        )

        serializer = StockMovementSerializer(movement)
        return Response(serializer.data, status=status.HTTP_201_CREATED)

    @action(detail=True, methods=['get'])
    def stock_history(self, request, pk=None):
        """Historique des mouvements de stock"""
        product = self.get_object()
        movements = product.stock_movements.all()[:50]
        serializer = StockMovementSerializer(movements, many=True)
        return Response(serializer.data)


class StockMovementViewSet(viewsets.ModelViewSet):
    """API endpoint pour les mouvements de stock"""
    queryset = StockMovement.objects.select_related('product').all()
    serializer_class = StockMovementSerializer

    def get_queryset(self):
        """Filtrer par produit ou type de mouvement"""
        queryset = super().get_queryset()
        product_id = self.request.query_params.get('product')
        movement_type = self.request.query_params.get('type')

        if product_id:
            queryset = queryset.filter(product_id=product_id)
        if movement_type:
            queryset = queryset.filter(movement_type=movement_type)
        return queryset
