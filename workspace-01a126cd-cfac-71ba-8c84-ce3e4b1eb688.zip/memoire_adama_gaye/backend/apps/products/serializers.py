"""
SmartStock Sénégal - Backend Django
Sérialiseurs pour l'API REST
"""
from rest_framework import serializers
from apps.products.models import Product, Category, StockMovement
from apps.sales.models import Client, Sale, SaleItem


# ==================== PRODUCTS ====================

class CategorySerializer(serializers.ModelSerializer):
    """Sérialiseur pour les catégories"""
    product_count = serializers.SerializerMethodField()

    class Meta:
        model = Category
        fields = ['id', 'name', 'description', 'product_count', 'created_at']
        read_only_fields = ['created_at']

    def get_product_count(self, obj):
        return obj.products.count()


class ProductSerializer(serializers.ModelSerializer):
    """Sérialiseur pour les produits"""
    category_name = serializers.CharField(source='category.name', read_only=True)
    current_stock = serializers.ReadOnlyField()
    is_low_stock = serializers.ReadOnlyField()
    profit_margin_percentage = serializers.ReadOnlyField()

    class Meta:
        model = Product
        fields = [
            'id', 'name', 'reference', 'category', 'category_name',
            'description', 'purchase_price', 'selling_price', 'unit',
            'min_stock_threshold', 'max_stock', 'is_active',
            'current_stock', 'is_low_stock', 'profit_margin_percentage',
            'created_at', 'updated_at'
        ]
        read_only_fields = ['created_at', 'updated_at']


class StockMovementSerializer(serializers.ModelSerializer):
    """Sérialiseur pour les mouvements de stock"""
    product_name = serializers.CharField(source='product.name', read_only=True)
    movement_type_display = serializers.CharField(
        source='get_movement_type_display', read_only=True
    )

    class Meta:
        model = StockMovement
        fields = [
            'id', 'product', 'product_name', 'movement_type',
            'movement_type_display', 'quantity', 'reason',
            'reference_document', 'date'
        ]
        read_only_fields = ['date']


# ==================== SALES ====================

class ClientSerializer(serializers.ModelSerializer):
    """Sérialiseur pour les clients"""
    total_purchases = serializers.ReadOnlyField()
    number_of_purchases = serializers.ReadOnlyField()

    class Meta:
        model = Client
        fields = [
            'id', 'name', 'phone', 'email', 'address', 'city',
            'client_type', 'is_active', 'total_purchases',
            'number_of_purchases', 'created_at'
        ]
        read_only_fields = ['created_at']


class SaleItemSerializer(serializers.ModelSerializer):
    """Sérialiseur pour les lignes de vente"""
    product_name = serializers.CharField(source='product.name', read_only=True)
    subtotal = serializers.ReadOnlyField()

    class Meta:
        model = SaleItem
        fields = [
            'id', 'product', 'product_name', 'quantity',
            'unit_price', 'discount', 'subtotal'
        ]


class SaleSerializer(serializers.ModelSerializer):
    """Sérialiseur pour les ventes"""
    items = SaleItemSerializer(many=True, read_only=True)
    client_name = serializers.CharField(source='client.name', read_only=True)
    payment_method_display = serializers.CharField(
        source='get_payment_method_display', read_only=True
    )

    class Meta:
        model = Sale
        fields = [
            'id', 'reference', 'client', 'client_name',
            'sale_date', 'payment_method', 'payment_method_display',
            'status', 'discount', 'total_amount', 'items',
            'notes', 'created_at'
        ]
        read_only_fields = ['created_at', 'total_amount']


class SaleCreateSerializer(serializers.ModelSerializer):
    """Sérialiseur pour la création de ventes (avec items)"""
    items = SaleItemSerializer(many=True)

    class Meta:
        model = Sale
        fields = [
            'reference', 'client', 'sale_date', 'payment_method',
            'discount', 'notes', 'items'
        ]

    def create(self, validated_data):
        """Créer une vente avec ses items"""
        items_data = validated_data.pop('items')
        sale = Sale.objects.create(**validated_data)

        total = 0
        for item_data in items_data:
            item = SaleItem.objects.create(sale=sale, **item_data)
            total += item.subtotal

        sale.total_amount = total - sale.discount
        sale.save()

        return sale


# ==================== DASHBOARD ====================

class DashboardSerializer(serializers.Serializer):
    """Sérialiseur pour les données du tableau de bord"""
    total_revenue = serializers.DecimalField(max_digits=12, decimal_places=2)
    total_sales = serializers.IntegerField()
    total_products = serializers.IntegerField()
    total_clients = serializers.IntegerField()
    low_stock_products = serializers.IntegerField()
    revenue_today = serializers.DecimalField(max_digits=12, decimal_places=2)
    top_products = serializers.ListField()
    recent_sales = SaleSerializer(many=True)
