"""
SmartStock Sénégal - Backend Django
Modèle de données : Products
"""
from django.db import models
from django.core.validators import MinValueValidator


class Category(models.Model):
    """Catégorie de produit (ex: Céréales, Boissons, Conserves...)"""
    name = models.CharField(max_length=100, verbose_name="Nom de la catégorie")
    description = models.TextField(blank=True, verbose_name="Description")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Catégorie"
        verbose_name_plural = "Catégories"
        ordering = ['name']

    def __str__(self):
        return self.name


class Product(models.Model):
    """Produit commercialisé par la PME"""
    UNIT_CHOICES = [
        ('kg', 'Kilogramme'),
        ('g', 'Gramme'),
        ('L', 'Litre'),
        ('unite', 'Unité'),
        ('carton', 'Carton'),
        ('sac', 'Sac (50kg)'),
        ('paquet', 'Paquet'),
    ]

    name = models.CharField(max_length=200, verbose_name="Nom du produit")
    reference = models.CharField(max_length=50, unique=True, verbose_name="Référence")
    category = models.ForeignKey(
        Category, on_delete=models.CASCADE, related_name='products',
        verbose_name="Catégorie"
    )
    description = models.TextField(blank=True, verbose_name="Description")
    purchase_price = models.DecimalField(
        max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0)],
        verbose_name="Prix d'achat (FCFA)"
    )
    selling_price = models.DecimalField(
        max_digits=10, decimal_places=2,
        validators=[MinValueValidator(0)],
        verbose_name="Prix de vente (FCFA)"
    )
    unit = models.CharField(
        max_length=10, choices=UNIT_CHOICES, default='unite',
        verbose_name="Unité de mesure"
    )
    min_stock_threshold = models.PositiveIntegerField(
        default=10,
        verbose_name="Seuil minimum de stock"
    )
    max_stock = models.PositiveIntegerField(
        default=1000,
        verbose_name="Stock maximum"
    )
    is_active = models.BooleanField(default=True, verbose_name="Actif")
    image = models.ImageField(upload_to='products/', blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name = "Produit"
        verbose_name_plural = "Produits"
        ordering = ['name']

    def __str__(self):
        return f"{self.name} ({self.reference})"

    @property
    def current_stock(self):
        """Retourne le stock actuel du produit"""
        return self.stock_movements.filter(
            movement_type='IN'
        ).aggregate(
            total_in=models.Sum('quantity')
        )['total_in'] or 0

    @property
    def is_low_stock(self):
        """Vérifie si le stock est en dessous du seuil minimum"""
        return self.current_stock <= self.min_stock_threshold

    @property
    def profit_margin(self):
        """Calcule la marge bénéficiaire en FCFA"""
        return self.selling_price - self.purchase_price

    @property
    def profit_margin_percentage(self):
        """Calcule la marge bénéficiaire en pourcentage"""
        if self.purchase_price > 0:
            return round((self.profit_margin / self.purchase_price) * 100, 2)
        return 0


class StockMovement(models.Model):
    """Mouvement de stock (entrée/sortie)"""
    MOVEMENT_TYPES = [
        ('IN', 'Entrée'),
        ('OUT', 'Sortie'),
        ('ADJUSTMENT', 'Ajustement'),
        ('RETURN', 'Retour'),
    ]

    product = models.ForeignKey(
        Product, on_delete=models.CASCADE, related_name='stock_movements',
        verbose_name="Produit"
    )
    movement_type = models.CharField(
        max_length=12, choices=MOVEMENT_TYPES,
        verbose_name="Type de mouvement"
    )
    quantity = models.PositiveIntegerField(verbose_name="Quantité")
    reason = models.CharField(max_length=200, blank=True, verbose_name="Motif")
    reference_document = models.CharField(
        max_length=100, blank=True,
        verbose_name="Document de référence"
    )
    performed_by = models.ForeignKey(
        'auth.User', on_delete=models.SET_NULL, null=True,
        verbose_name="Effectué par"
    )
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name = "Mouvement de stock"
        verbose_name_plural = "Mouvements de stock"
        ordering = ['-date']

    def __str__(self):
        return f"{self.get_movement_type_display()} - {self.product.name} ({self.quantity})"
