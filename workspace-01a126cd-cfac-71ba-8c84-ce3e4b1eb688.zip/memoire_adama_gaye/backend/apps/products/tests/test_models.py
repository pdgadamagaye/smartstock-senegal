"""
SmartStock Sénégal - Tests Unitaires
Tests pour le module Products
"""
import pytest
from django.test import TestCase
from django.contrib.auth.models import User
from rest_framework.test import APIClient
from rest_framework import status

from apps.products.models import Product, Category, StockMovement


@pytest.mark.django_db
class TestCategoryModel(TestCase):
    """Tests pour le modèle Category"""

    def setUp(self):
        self.category = Category.objects.create(
            name="Céréales",
            description="Riz, mil, maïs, etc."
        )

    def test_category_creation(self):
        """Test de création d'une catégorie"""
        self.assertEqual(self.category.name, "Céréales")
        self.assertEqual(str(self.category), "Céréales")

    def test_category_ordering(self):
        """Test de l'ordre alphabétique des catégories"""
        cat2 = Category.objects.create(name="Boissons")
        categories = list(Category.objects.all())
        self.assertEqual(categories[0].name, "Boissons")
        self.assertEqual(categories[1].name, "Céréales")


@pytest.mark.django_db
class TestProductModel(TestCase):
    """Tests pour le modèle Product"""

    def setUp(self):
        self.category = Category.objects.create(name="Céréales")
        self.product = Product.objects.create(
            name="Riz parfumé 5kg",
            reference="RIZ-001",
            category=self.category,
            purchase_price=3500,
            selling_price=4500,
            unit="carton",
            min_stock_threshold=20,
            max_stock=500
        )
        self.user = User.objects.create_user(
            username='testuser', password='testpass123'
        )

    def test_product_creation(self):
        """Test de création d'un produit"""
        self.assertEqual(self.product.name, "Riz parfumé 5kg")
        self.assertEqual(self.product.reference, "RIZ-001")
        self.assertEqual(self.product.purchase_price, 3500)
        self.assertEqual(self.product.selling_price, 4500)

    def test_profit_margin(self):
        """Test du calcul de la marge bénéficiaire"""
        self.assertEqual(self.product.profit_margin, 1000)
        self.assertEqual(self.product.profit_margin_percentage, 28.57)

    def test_profit_margin_zero_purchase_price(self):
        """Test marge avec prix d'achat = 0"""
        self.product.purchase_price = 0
        self.product.save()
        self.assertEqual(self.product.profit_margin_percentage, 0)

    def test_current_stock_empty(self):
        """Test stock initial = 0 (aucun mouvement)"""
        self.assertEqual(self.product.current_stock, 0)

    def test_current_stock_with_movements(self):
        """Test stock après mouvements"""
        StockMovement.objects.create(
            product=self.product,
            movement_type='IN',
            quantity=100,
            reason='Approvisionnement',
            performed_by=self.user
        )
        StockMovement.objects.create(
            product=self.product,
            movement_type='OUT',
            quantity=30,
            reason='Vente',
            performed_by=self.user
        )
        # current_stock calcule uniquement les IN
        # (pour un calcul complet, il faudrait aussi soustraire les OUT)
        self.assertEqual(self.product.current_stock, 100)

    def test_is_low_stock(self):
        """Test détection stock faible"""
        # Stock = 0, seuil = 20 → should be low
        self.assertTrue(self.product.is_low_stock)

        # Ajouter du stock au-dessus du seuil
        StockMovement.objects.create(
            product=self.product,
            movement_type='IN',
            quantity=50,
            performed_by=self.user
        )
        # Refresh pour recalculer
        self.product.refresh_from_db()
        self.assertFalse(self.product.is_low_stock)

    def test_product_str(self):
        """Test de la représentation string"""
        self.assertEqual(str(self.product), "Riz parfumé 5kg (RIZ-001)")


@pytest.mark.django_db
class TestStockMovement(TestCase):
    """Tests pour les mouvements de stock"""

    def setUp(self):
        self.category = Category.objects.create(name="Conserves")
        self.product = Product.objects.create(
            name="Thon en boîte",
            reference="THO-001",
            category=self.category,
            purchase_price=500,
            selling_price=750,
            unit="carton",
            min_stock_threshold=10
        )
        self.user = User.objects.create_user(
            username='storekeeper', password='testpass123'
        )

    def test_stock_in_movement(self):
        """Test d'un mouvement d'entrée"""
        movement = StockMovement.objects.create(
            product=self.product,
            movement_type='IN',
            quantity=50,
            reason='Réception commande',
            performed_by=self.user
        )
        self.assertEqual(movement.quantity, 50)
        self.assertEqual(movement.movement_type, 'IN')

    def test_stock_out_movement(self):
        """Test d'un mouvement de sortie"""
        movement = StockMovement.objects.create(
            product=self.product,
            movement_type='OUT',
            quantity=5,
            reason='Vente directe',
            performed_by=self.user
        )
        self.assertEqual(movement.quantity, 5)

    def test_movement_str(self):
        """Test de la représentation string"""
        movement = StockMovement.objects.create(
            product=self.product,
            movement_type='IN',
            quantity=50,
            performed_by=self.user
        )
        self.assertIn("Entrée", str(movement))
        self.assertIn("Thon en boîte", str(movement))


@pytest.mark.django_db
class TestProductAPI(APIClient):
    """Tests pour l'API des produits"""

    def setUp(self):
        self.client = APIClient()
        self.user = User.objects.create_user(
            username='admin', password='adminpass123'
        )
        self.client.force_authenticate(user=self.user)

        self.category = Category.objects.create(name="Céréales")
        self.product = Product.objects.create(
            name="Mil 25kg",
            reference="MIL-001",
            category=self.category,
            purchase_price=8000,
            selling_price=10000,
            unit="sac"
        )

    def test_list_products(self):
        """Test de la liste des produits"""
        response = self.client.get('/api/products/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertGreaterEqual(len(response.data['results']), 1)

    def test_retrieve_product(self):
        """Test de la récupération d'un produit"""
        response = self.client.get(f'/api/products/{self.product.id}/')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(response.data['name'], "Mil 25kg")

    def test_create_product(self):
        """Test de la création d'un produit"""
        data = {
            'name': 'Maïs 10kg',
            'reference': 'MAI-001',
            'category': self.category.id,
            'purchase_price': 5000,
            'selling_price': 6500,
            'unit': 'sac',
            'min_stock_threshold': 15
        }
        response = self.client.post('/api/products/', data)
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertEqual(response.data['name'], 'Maïs 10kg')

    def test_create_product_duplicate_reference(self):
        """Test de création avec référence déjà existante"""
        data = {
            'name': 'Autre produit',
            'reference': 'MIL-001',  # Déjà utilisé
            'category': self.category.id,
            'purchase_price': 5000,
            'selling_price': 6500,
            'unit': 'sac'
        }
        response = self.client.post('/api/products/', data)
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_add_stock(self):
        """Test de l'ajout de stock via l'API"""
        data = {'quantity': 100, 'reason': 'Approvisionnement'}
        response = self.client.post(
            f'/api/products/{self.product.id}/add_stock/', data
        )
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)

    def test_add_stock_invalid_quantity(self):
        """Test d'ajout de stock avec quantité invalide"""
        data = {'quantity': -10, 'reason': 'Test'}
        response = self.client.post(
            f'/api/products/{self.product.id}/add_stock/', data
        )
        self.assertEqual(response.status_code, status.HTTP_400_BAD_REQUEST)

    def test_unauthenticated_access(self):
        """Test d'accès sans authentification"""
        client = APIClient()  # Non authentifié
        response = client.get('/api/products/')
        self.assertEqual(response.status_code, status.HTTP_401_UNAUTHORIZED)

    def test_search_products(self):
        """Test de la recherche de produits"""
        response = self.client.get('/api/products/?search=Mil')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
