# 📧 CONTACT CDA — Emails et Stratégie

## 📧 EMAIL 1 : Premier contact formel

**Destinataire :** M. Karim FILFILI, Directeur Général de la CDA  
**Email :** karimfilfili@cdasenegal.com  
**Téléphone :** +221 33 823 11 20 / +221 33 836 33 04  
**Adresse :** 31 rue du Dr Thèze, Quartier Plateau, Dakar

---

**Objet :** Demande de collaboration académique — Outil d'intelligence artificielle pour l'optimisation des stocks

Monsieur le Directeur Général,

Je suis **Adama GAYE**, étudiant en Licence 3 Informatique de Gestion à l'**Université Catholique de l'Afrique de l'Ouest (UCAO)** de Dakar.

Dans le cadre de mon mémoire de fin d'études, je développe un **système d'aide à la décision intégrant l'intelligence artificielle** pour optimiser la gestion commerciale et les stocks des entreprises de distribution agroalimentaire.

La **CDA (Chaîne de Distribution Alimentaire)**, par son activité de distribution de produits alimentaires et ses différents sites (siège au Plateau, succursale à Sébikotane), représente le cas d'étude idéal pour ce travail.

### Ce que je propose

1. **Un entretien** (30-45 minutes) pour comprendre vos processus actuels de gestion des stocks.
2. **L'accès à vos données historiques** de ventes (6 à 24 mois), traitées de manière strictement confidentielle.
3. **Un outil gratuit** de gestion commerciale avec prédictions IA, que vous pourrez utiliser librement.

### Garanties

- **Confidentialité totale** : Accord de confidentialité signable
- **Gratuité complète** : Outil développé sans aucun coût pour la CDA
- **Restitution** : Le code source et la documentation vous appartiennent
- **Formation** : Formation de votre personnel

### Intérêt pour la CDA

- Un outil de prédiction des ventes adapté à vos produits
- Des alertes automatiques de stock pour chaque site
- Un tableau de bord multi-sites avec indicateurs de performance
- Un rapport d'analyse de vos données historiques

Je suis disponible pour un entretien à votre convenance, à vos bureaux au 31 rue du Dr Thèze, Plateau.

Je vous prie d'agréer, Monsieur le Directeur Général, l'expression de ma considération distinguée.

**Adama GAYE**  
Licence 3 — Informatique de Gestion  
Université Catholique de l'Afrique de l'Ouest (UCAO) — Dakar  
📞 [Votre numéro]  
📧 [Votre email]

---

## 📧 EMAIL 2 : Relance (si pas de réponse après 5 jours)

**Objet :** Relance — Projet universitaire gratuit pour la CDA

Monsieur le Directeur Général,

Je me permets de vous relancer concernant ma proposition de collaboration académique pour le développement d'un outil gratuit d'intelligence artificielle destiné à optimiser la gestion des stocks de la CDA.

Serait-il possible de convenir d'un bref entretien de 30 minutes à votre convenance ?

Cordialement,  
**Adama GAYE** — UCAO Dakar  
📞 [Votre numéro]

---

## 📞 SCRIPT TÉLÉPHONIQUE (+221 33 823 11 20)

```
"Bonjour, je m'appelle Adama GAYE, je suis étudiant en informatique
à l'UCAO. Je souhaiterais parler à Monsieur Karim FILFILI, le
Directeur Général, concernant un projet de collaboration
académique. Est-ce possible ?"

[Si on demande de préciser]

"Il s'agit d'un projet de mémoire de fin d'études portant sur le
développement d'un outil gratuit d'intelligence artificielle pour
aider les entreprises de distribution alimentaire à mieux gérer
leurs stocks."

[Si on donne un RDV]

"Merci beaucoup. Je viendrai avec les documents de l'université."
```

---

## 📋 DOCUMENTS À PRÉPARER

- [ ] Fiche sujet imprimée (PDF)
- [ ] Lettre de recommandation de l'encadrant UCAO
- [ ] CV académique
- [ ] Résumé du projet (1 page)
- [ ] Accord de confidentialité

---

## 📋 STRATÉGIE DE CONTACT

### Qui contacter ?
1. **Le Directeur Général** (M. Karim FILFILI) — email formel
2. **Le Directeur des Opérations** — téléphone
3. **Le Responsable informatique** — si existant

### Calendrier
| Date | Action |
|------|--------|
| 15 août | Envoyer email formel |
| 16 août | Appeler le standard |
| 17-18 août | Visiter le siège au Plateau |
| 19-21 août | Obtenir le RDV |
| 22 août | Premier entretien + collecte données |

### Plans B et C (si CDA ne répond pas)
- **Plan B** : Marché de Tilène/Colobane — grossiste alimentaire
- **Plan C** : COSEMAD (+221 33 869 04 40) ou Au Bon Accueil (+221 33 821 74 05)
