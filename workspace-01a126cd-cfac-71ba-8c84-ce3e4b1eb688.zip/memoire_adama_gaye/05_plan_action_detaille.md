# 📅 PLAN D'ACTION — 10 MOIS
## Cas d'étude : CDA — Chaîne de Distribution Alimentaire

---

# 🔴 PHASE 0 : CONTACT CDA (15-22 août 2026)

| Jour | Action |
|------|--------|
| 15 août | Email à karimfilfili@cdasenegal.com + lettre recommandation UCAO |
| 16 août | Appel +221 33 823 11 20 + commencer Python |
| 17-18 août | Visiter le 31 rue du Dr Thèze, Plateau |
| 19-21 août | Entretien + collecte données |
| 22 août | **BILAN** : accord obtenu + GitHub créé |

---

# 🔴 PHASE 1 : APPRENTISSAGE (22 août → 21 sept)

| Semaine | Dates | Technologie | Livrable |
|---------|-------|-------------|----------|
| S1 | 22-28 août | Python + PostgreSQL | Script Python + BDD |
| S2 | 29 août-4 sept | Django Backend | API REST complète |
| S3 | 5-11 sept | React Frontend | Dashboard connecté |
| S4 | 12-21 sept | IA (4 modèles) + Reporting | Comparaison + PDF auto |

---

# 🟡 PHASE 2 : EXPÉRIMENTATION IA (22 sept → 30 nov)

| Semaine | Dates | Tâches | Livrable |
|---------|-------|--------|----------|
| S5 | 22-28 sept | 4 modèles (SMA, HW, SARIMA, Prophet) | Code Python |
| S6 | 29 sept-5 oct | Comparaison + métriques (MAPE, RMSE, MAE) | Tableau comparatif |
| S7 | 6-12 oct | Variables culturelles (Ramadan, Tabaski) | Impact mesuré |
| S8 | 13-19 oct | Tests statistiques (Diebold-Mariano) | Validation |
| S9 | 20-26 oct | Sélection meilleur modèle | Rapport scientifique |

---

# 🟡 PHASE 3 : DÉVELOPPEMENT (27 nov → 28 fév 2027)

| Semaine | Dates | Tâches | Livrable |
|---------|-------|--------|----------|
| S10 | 27 nov-3 déc | Intégration (IA + Dashboard + Reporting) | App fonctionnelle |
| S11 | 4-10 déc | Module reporting PDF automatique | Rapports générés |
| S12 | 11-17 déc | Module alertes (seuils + prédictions) | Alertes actives |
| S13 | 18-24 déc | Interface responsive + multi-sites | App complète |
| S14 | 25-31 déc | REPOS — Fêtes | Repos |
| S15 | 1-7 jan | Tests unitaires (coverage > 90%) | Tests complets |
| S16 | 8-14 jan | Déploiement (Railway/Render) | App en ligne |
| S17 | 15-21 jan | Tests avec la CDA | Rapport de tests |
| S18 | 22-28 jan | Corrections post-tests | App validée |

---

# 🟢 PHASE 4 : RÉDACTION (12 fév → 31 mai 2027)

| Mois | Tâches | Livrables |
|------|--------|-----------|
| **Fév** | Chap. 1 (Littérature) + Chap. 2 (Analyse CDA) | 50 pages |
| **Mars** | Chap. 3 ⭐ (Comparaison 4 modèles) | 22 pages |
| **Avril** | Chap. 4 (Conception) + Chap. 5 (Implémentation) | 35 pages |
| **Mai** | Chap. 6 (Tests) + Conclusion + Annexes + Relecture | Mémoire complet ~130p |

---

# 🔵 PHASE 5 : SOUTENANCE (Juin 2027)

| Période | Tâches |
|---------|--------|
| 1-15 juin | Répétitions + démo live CDA |
| 16-30 juin | **🎓 SOUTENANCE** |

---

# 🎯 RÈGLES

1. Minimum 2h/jour en semaine, 4h/jour le week-end
2. Commit Git tous les jours
3. Bilan chaque dimanche
4. Ne jamais passer à la semaine suivante sans validation
5. Documenter chaque décision technique

---

*4 modèles : Moyenne Mobile, Holt-Winters, SARIMA, Prophet*
