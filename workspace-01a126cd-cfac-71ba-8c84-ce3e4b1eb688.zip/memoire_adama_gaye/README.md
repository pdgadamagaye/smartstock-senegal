# 🇸🇳 SmartStock — CDA

## Système d'Aide à la Décision pour les PME Sénégalaises
### Prédiction IA + Tableau de Bord + Reporting Automatisé

---

**Mémoire de fin d'études — Licence 3 Informatique de Gestion**  
**Étudiant :** Adama GAYE — UCAO Dakar — 2026-2027

---

## 🎯 Problématique

> *Comment concevoir un système d'aide à la décision intégré, combinant la prédiction des ventes par intelligence artificielle, le pilotage par tableau de bord en temps réel et l'automatisation du reporting, afin d'améliorer la performance commerciale des PME de distribution alimentaire sénégalaises ?*

## 🏢 Cas d'étude : CDA

| Information | Détail |
|-------------|--------|
| **Nom** | Chaîne de Distribution Alimentaire (CDA) |
| **Statut** | Société Anonyme |
| **Siège** | 31 rue du Dr Thèze, Plateau, Dakar |
| **Succursale** | Sébikotane |
| **DG** | M. Karim FILFILI |
| **Contact** | +221 33 823 11 20 |

## 🧩 Les 3 Piliers

| Pilier | Description | Technologies |
|--------|-------------|-------------|
| 🧠 **PRÉDICTION IA** | 4 modèles comparés (SMA, Holt-Winters, SARIMA, Prophet) + variables culturelles | Python, Prophet, statsmodels |
| 📊 **TABLEAU DE BORD** | KPIs temps réel, multi-sites, graphiques interactifs | React.js, Chart.js |
| 📄 **REPORTING AUTO** | Rapports PDF automatiques, planification, envoi email | ReportLab, Pandas |

## 🚀 Installation

```bash
# Backend
cd backend && pip install -r requirements.txt
python manage.py migrate && python manage.py runserver

# Frontend
cd frontend && npm install && npm start

# Module IA (comparaison 4 modèles)
cd ml && python model_comparison.py

# Module Reporting (démo)
cd backend/apps/reporting && python services.py
```

## 📊 Résultats attendus

| Pilier | Résultat | Mesure |
|--------|----------|--------|
| IA | Meilleur modèle identifié parmi 4 | MAPE < 15% |
| Tableau de bord | Visibilité temps réel multi-sites | -60% temps de décision |
| Reporting | Rapports automatiques | -80% temps de génération |

---

© 2026-2027 Adama GAYE — UCAO Dakar — Cas d'étude : CDA
